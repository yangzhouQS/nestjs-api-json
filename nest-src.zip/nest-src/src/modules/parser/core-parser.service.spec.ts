import { describe, it, expect, beforeEach, vi } from 'vitest';
import { CoreParserService } from './core-parser.service';
import { APIJSONRequest, ParseResult, TableQuery } from '@/interfaces/apijson-request.interface';

describe('CoreParserService', () => {
  let service: CoreParserService;

  beforeEach(() => {
    service = new CoreParserService();
  });

  describe('parse', () => {
    it('should parse a simple GET request', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          '@column': 'id,name,age',
        },
      };

      const result = await service.parse(request);

      expect(result).toBeDefined();
      expect(result.tables).toBeDefined();
      expect(result.tables.User).toBeDefined();
      expect(result.tables.User.name).toBe('User');
      expect(result.tables.User.operation).toBe('GET');
      expect(result.tables.User.where).toEqual({ id: 1 });
      expect(result.tables.User.columns).toBe('id,name,age');
    });

    it('should parse HEAD request', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          '@column': 'COUNT(*):count',
        },
        '@method': 'HEAD',
      };

      const result = await service.parse(request);

      expect(result.tables.User.operation).toBe('HEAD');
    });

    it('should parse GETS request for array query', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          count: 10,
          page: 0,
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]']).toBeDefined();
      expect(result.tables['User[]'].operation).toBe('GETS');
      expect(result.tables['User[]'].isArray).toBe(true);
      expect(result.tables['User[]'].limit).toBe(10);
      expect(result.tables['User[]'].offset).toBe(0);
    });

    it('should parse HEADS request for array count', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          count: 10,
          User: {
            age>': 18,
          },
        },
        '@method': 'HEADS',
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].operation).toBe('HEADS');
    });

    it('should parse POST request for insert', async () => {
      const request: APIJSONRequest = {
        User: {
          name: '张三',
          age: 25,
        },
        '@method': 'POST',
      };

      const result = await service.parse(request);

      expect(result.tables.User.operation).toBe('POST');
      expect(result.tables.User.data).toEqual({ name: '张三', age: 25 });
    });

    it('should parse PUT request for update', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          name: '李四',
          age: 30,
        },
        '@method': 'PUT',
      };

      const result = await service.parse(request);

      expect(result.tables.User.operation).toBe('PUT');
      expect(result.tables.User.where).toEqual({ id: 1 });
      expect(result.tables.User.data).toEqual({ name: '李四', age: 30 });
    });

    it('should parse DELETE request', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        '@method': 'DELETE',
      };

      const result = await service.parse(request);

      expect(result.tables.User.operation).toBe('DELETE');
      expect(result.tables.User.where).toEqual({ id: 1 });
    });

    it('should parse CRUD request with mixed operations', async () => {
      const request: APIJSONRequest = {
        User: {
          '@method': 'POST',
          name: '张三',
          age: 25,
        },
        Moment: {
          '@method': 'PUT',
          id: 1,
          content: '更新内容',
        },
        Comment: {
          '@method': 'DELETE',
          id: 1,
        },
        '@method': 'CRUD',
      };

      const result = await service.parse(request);

      expect(result.tables.User.operation).toBe('POST');
      expect(result.tables.Moment.operation).toBe('PUT');
      expect(result.tables.Comment.operation).toBe('DELETE');
    });

    it('should parse multiple tables', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          '@column': 'id,name',
        },
        Moment: {
          userId: 1,
          '@column': 'id,content',
        },
        Comment: {
          momentId: 1,
          '@column': 'id,content',
        },
      };

      const result = await service.parse(request);

      expect(Object.keys(result.tables)).toHaveLength(3);
      expect(result.tables.User).toBeDefined();
      expect(result.tables.Moment).toBeDefined();
      expect(result.tables.Comment).toBeDefined();
    });

    it('should parse empty request', async () => {
      const request: APIJSONRequest = {};

      const result = await service.parse(request);

      expect(result.tables).toEqual({});
      expect(result.directives).toEqual({});
    });

    it('should preserve original request', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
      };

      const result = await service.parse(request);

      expect(result.original).toEqual(request);
    });
  });

  describe('parseTableQuery - Condition Operators', () => {
    it('should parse equality condition', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ id: 1 });
    });

    it('should parse greater than condition (>)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age>': 18,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age>': 18 });
    });

    it('should parse less than condition (<)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age<': 60,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age<': 60 });
    });

    it('should parse greater than or equal condition (>=)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age>=': 18,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age>=': 18 });
    });

    it('should parse less than or equal condition (<=)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age<=': 60,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age<=': 60 });
    });

    it('should parse not equal condition (!=)', async () => {
      const request: APIJSONRequest = {
        User: {
          'id!=': 1,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'id!=': 1 });
    });

    it('should parse fuzzy match condition (~)', async () => {
      const request: APIJSONRequest = {
        User: {
          'name~': '张',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'name~': '张' });
    });

    it('should parse not fuzzy match condition (!~)', async () => {
      const request: APIJSONRequest = {
        User: {
          'name!~': '张',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'name!~': '张' });
    });

    it('should parse IN condition ({})', async () => {
      const request: APIJSONRequest = {
        User: {
          'id{}': [1, 2, 3],
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'id{}': [1, 2, 3] });
    });

    it('should parse NOT IN condition (!{})', async () => {
      const request: APIJSONRequest = {
        User: {
          'id!{}': [1, 2, 3],
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'id!{}': [1, 2, 3] });
    });

    it('should parse BETWEEN condition (><)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age><': [18, 60],
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age><': [18, 60] });
    });

    it('should parse NOT BETWEEN condition (!><)', async () => {
      const request: APIJSONRequest = {
        User: {
          'age!><': [18, 60],
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'age!><': [18, 60] });
    });

    it('should parse array contains condition (<>)', async () => {
      const request: APIJSONRequest = {
        User: {
          'tagIds<>': 1,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'tagIds<>': 1 });
    });

    it('should parse array not contains condition (!<>)', async () => {
      const request: APIJSONRequest = {
        User: {
          'tagIds!<>': 1,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({ 'tagIds!<>': 1 });
    });

    it('should parse multiple conditions', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          'age>': 18,
          'name~': '张',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({
        id: 1,
        'age>': 18,
        'name~': '张',
      });
    });
  });

  describe('parseTableQuery - Special Fields', () => {
    it('should parse @column field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'id,name,age',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('id,name,age');
    });

    it('should parse @order field with ASC', async () => {
      const request: APIJSONRequest = {
        User: {
          '@order': 'name+',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.order).toEqual(['name+']);
    });

    it('should parse @order field with DESC', async () => {
      const request: APIJSONRequest = {
        User: {
          '@order': 'name-',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.order).toEqual(['name-']);
    });

    it('should parse @order field with multiple columns', async () => {
      const request: APIJSONRequest = {
        User: {
          '@order': 'name+,age-',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.order).toEqual(['name+', 'age-']);
    });

    it('should parse @group field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@group': 'department',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.group).toEqual(['department']);
    });

    it('should parse @having field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@having': 'count(*)>5',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.having).toEqual({ 'count(*)>5': 5 });
    });

    it('should parse @cache field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@cache': 60,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.cache).toBe(60);
    });

    it('should parse @explain field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@explain': true,
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.explain).toBe(true);
    });

    it('should parse @role field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@role': 'ADMIN',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.role).toBe('ADMIN');
    });

    it('should parse @database field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@database': 'test',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.database).toBe('test');
    });

    it('should parse @schema field', async () => {
      const request: APIJSONRequest = {
        User: {
          '@schema': 'public',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.schema).toBe('public');
    });
  });

  describe('parseJoins - JOIN Types', () => {
    it('should parse APP JOIN (@)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '@/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins).toBeDefined();
      expect(result.tables.User.joins).toHaveLength(1);
      expect(result.tables.User.joins[0].type).toBe('@');
    });

    it('should parse INNER JOIN (&)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '&/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('&');
    });

    it('should parse FULL JOIN (|)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '|/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('|');
    });

    it('should parse LEFT JOIN (<)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '</Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('<');
    });

    it('should parse RIGHT JOIN (>)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '>/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('>');
    });

    it('should parse OUTER JOIN (!)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '!/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('!');
    });

    it('should parse SIDE JOIN (^)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '^/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('^');
    });

    it('should parse ANTI JOIN (()', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '(/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('(');
    });

    it('should parse FOREIGN JOIN ())', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: ')/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe(')');
    });

    it('should parse ASOF JOIN (~)', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '~/Moment/userId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].type).toBe('~');
    });

    it('should parse multiple JOINs', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: '&/Moment/userId@,</Comment/toId@',
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins).toHaveLength(2);
      expect(result.tables.User.joins[0].type).toBe('&');
      expect(result.tables.User.joins[1].type).toBe('<');
    });

    it('should parse JOIN with conditions', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        join: {
          '&/Moment/userId@': {
            'age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.joins[0].on).toBeDefined();
    });
  });

  describe('parseReference - Reference Assignment', () => {
    it('should parse simple reference assignment', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        Moment: {
          'userId@': '/User/id',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.Moment.where).toEqual({ 'userId@': '/User/id' });
      expect(result.tables.Moment.references).toBeDefined();
      expect(result.tables.Moment.references?.userId).toBe('/User/id');
    });

    it('should parse array reference assignment', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          count: 5,
          User: {
            age>': 18,
          },
        },
        Moment: {
          'userId{}@': '[]/User/id',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.Moment.where).toEqual({ 'userId{}@': '[]/User/id' });
    });

    it('should parse nested reference assignment', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
        },
        Moment: {
          'userId@': '/User/id',
        },
        Comment: {
          'momentId@': '/Moment/id',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.Comment.where).toEqual({ 'momentId@': '/Moment/id' });
    });
  });

  describe('parseArrayQuery - Array Queries', () => {
    it('should parse array query with count and page', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          count: 10,
          page: 1,
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]']).toBeDefined();
      expect(result.tables['User[]'].limit).toBe(10);
      expect(result.tables['User[]'].offset).toBe(10);
      expect(result.tables['User[]'].isArray).toBe(true);
    });

    it('should parse array query with query type 0 (data only)', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          query: 0,
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].query).toBe(0);
    });

    it('should parse array query with query type 1 (count only)', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          query: 1,
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].query).toBe(1);
    });

    it('should parse array query with query type 2 (data and count)', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          query: 2,
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].query).toBe(2);
    });

    it('should parse array query without count (default to 10)', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].limit).toBe(10);
    });

    it('should parse array query without page (default to 0)', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          User: {
            age>': 18,
          },
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]'].offset).toBe(0);
    });
  });

  describe('parseAggregateFunctions', () => {
    it('should parse COUNT function', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'COUNT(*):count',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('COUNT(*):count');
    });

    it('should parse SUM function', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'SUM(age):totalAge',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('SUM(age):totalAge');
    });

    it('should parse AVG function', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'AVG(age):avgAge',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('AVG(age):avgAge');
    });

    it('should parse MIN function', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'MIN(age):minAge',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('MIN(age):minAge');
    });

    it('should parse MAX function', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'MAX(age):maxAge',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('MAX(age):maxAge');
    });

    it('should parse multiple aggregate functions', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'COUNT(*):count,SUM(age):totalAge,AVG(age):avgAge',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.columns).toBe('COUNT(*):count,SUM(age):totalAge,AVG(age):avgAge');
    });
  });

  describe('parseDirectives - Global Directives', () => {
    it('should parse @tag directive', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
        '@tag': 'getUser',
      };

      const result = await service.parse(request);

      expect(result.directives['@tag']).toBe('getUser');
    });

    it('should parse @version directive', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
        '@version': 1,
      };

      const result = await service.parse(request);

      expect(result.directives['@version']).toBe(1);
    });

    it('should parse @format directive', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
        '@format': true,
      };

      const result = await service.parse(request);

      expect(result.directives['@format']).toBe(true);
    });

    it('should parse @explain directive', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
        '@explain': true,
      };

      const result = await service.parse(request);

      expect(result.directives['@explain']).toBe(true);
    });

    it('should parse all global directives', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
        '@tag': 'getUser',
        '@version': 1,
        '@format': true,
        '@explain': true,
        '@role': 'ADMIN',
        '@database': 'test',
        '@schema': 'public',
      };

      const result = await service.parse(request);

      expect(result.directives['@tag']).toBe('getUser');
      expect(result.directives['@version']).toBe(1);
      expect(result.directives['@format']).toBe(true);
      expect(result.directives['@explain']).toBe(true);
      expect(result.directives['@role']).toBe('ADMIN');
      expect(result.directives['@database']).toBe('test');
      expect(result.directives['@schema']).toBe('public');
    });
  });

  describe('Edge Cases', () => {
    it('should handle very long table name', async () => {
      const longTableName = 'a'.repeat(100);
      const request: APIJSONRequest = {
        [longTableName]: { id: 1 },
      };

      const result = await service.parse(request);

      expect(result.tables[longTableName]).toBeDefined();
    });

    it('should handle table name with special characters', async () => {
      const request: APIJSONRequest = {
        'User_Table': { id: 1 },
      };

      const result = await service.parse(request);

      expect(result.tables['User_Table']).toBeDefined();
    });

    it('should handle table name with numbers', async () => {
      const request: APIJSONRequest = {
        'User123': { id: 1 },
      };

      const result = await service.parse(request);

      expect(result.tables['User123']).toBeDefined();
    });

    it('should handle very large limit', async () => {
      const request: APIJSONRequest = {
        User: { limit: 999999 },
      };

      const result = await service.parse(request);

      expect(result.tables.User.limit).toBe(999999);
    });

    it('should handle very large offset', async () => {
      const request: APIJSONRequest = {
        User: { offset: 999999 },
      };

      const result = await service.parse(request);

      expect(result.tables.User.offset).toBe(999999);
    });

    it('should handle zero limit (default to 10)', async () => {
      const request: APIJSONRequest = {
        User: { limit: 0 },
      };

      const result = await service.parse(request);

      expect(result.tables.User.limit).toBe(10);
    });

    it('should handle negative limit (use absolute value)', async () => {
      const request: APIJSONRequest = {
        User: { limit: -10 },
      };

      const result = await service.parse(request);

      expect(result.tables.User.limit).toBe(10);
    });

    it('should handle many tables', async () => {
      const request: APIJSONRequest = {};
      for (let i = 0; i < 50; i++) {
        request[`Table${i}`] = { id: i };
      }

      const result = await service.parse(request);

      expect(Object.keys(result.tables)).toHaveLength(50);
    });

    it('should handle complex nested conditions', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          'age>': 18,
          'age<': 60,
          'name~': '张',
          'status': 'active',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toBeDefined();
      expect(Object.keys(result.tables.User.where)).toHaveLength(5);
    });

    it('should handle empty where', async () => {
      const request: APIJSONRequest = {
        User: {},
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({});
    });

    it('should handle null where', async () => {
      const request: APIJSONRequest = {
        User: { where: null },
      };

      const result = await service.parse(request);

      expect(result.tables.User.where).toEqual({});
    });
  });

  describe('Error Handling', () => {
    it('should handle malformed request gracefully', async () => {
      const request: any = {
        User: null,
      };

      const result = await service.parse(request);

      expect(result).toBeDefined();
      expect(result.tables).toBeDefined();
    });

    it('should handle circular reference', async () => {
      const request: APIJSONRequest = {
        User: { id: 1 },
      };
      (request as any).circular = request;

      const result = await service.parse(request);

      expect(result).toBeDefined();
    });

    it('should handle undefined table query', async () => {
      const request: APIJSONRequest = {
        User: undefined,
      };

      const result = await service.parse(request);

      expect(result.tables.User).toBeDefined();
      expect(result.tables.User.columns).toEqual(['*']);
    });
  });

  describe('Complex Queries', () => {
    it('should parse query with all features', async () => {
      const request: APIJSONRequest = {
        User: {
          '@column': 'id,name,age,COUNT(*) AS total',
          '@order': 'name+,age-',
          '@group': 'department',
          '@having': 'COUNT(*)>5',
          '@cache': 60,
          '@role': 'ADMIN',
          id: 1,
          'age>': 18,
          'name~': '张',
        },
        Moment: {
          '@column': 'id,content',
          'userId@': '/User/id',
        },
        '@tag': 'getUserWithMoments',
        '@version': 1,
        '@format': true,
      };

      const result = await service.parse(request);

      expect(result.tables.User).toBeDefined();
      expect(result.tables.Moment).toBeDefined();
      expect(result.tables.User.columns).toBe('id,name,age,COUNT(*) AS total');
      expect(result.tables.User.order).toEqual(['name+', 'age-']);
      expect(result.tables.User.group).toEqual(['department']);
      expect(result.tables.User.cache).toBe(60);
      expect(result.tables.User.role).toBe('ADMIN');
      expect(result.tables.Moment.where).toEqual({ 'userId@': '/User/id' });
      expect(result.directives['@tag']).toBe('getUserWithMoments');
      expect(result.directives['@version']).toBe(1);
      expect(result.directives['@format']).toBe(true);
    });

    it('should parse multi-table JOIN query', async () => {
      const request: APIJSONRequest = {
        User: {
          id: 1,
          '@column': 'id,name',
        },
        Moment: {
          'userId@': '/User/id',
          '@column': 'id,content',
        },
        Comment: {
          'momentId@': '/Moment/id',
          '@column': 'id,content',
        },
      };

      const result = await service.parse(request);

      expect(result.tables.User).toBeDefined();
      expect(result.tables.Moment).toBeDefined();
      expect(result.tables.Comment).toBeDefined();
      expect(result.tables.Moment.where).toEqual({ 'userId@': '/User/id' });
      expect(result.tables.Comment.where).toEqual({ 'momentId@': '/Moment/id' });
    });

    it('should parse array query with JOIN', async () => {
      const request: APIJSONRequest = {
        'User[]': {
          count: 10,
          page: 0,
          User: {
            age>': 18,
          },
        },
        Moment: {
          'userId{}@': '[]/User/id',
          '@column': 'id,content',
        },
      };

      const result = await service.parse(request);

      expect(result.tables['User[]']).toBeDefined();
      expect(result.tables.Moment).toBeDefined();
      expect(result.tables.Moment.where).toEqual({ 'userId{}@': '[]/User/id' });
    });
  });
});
