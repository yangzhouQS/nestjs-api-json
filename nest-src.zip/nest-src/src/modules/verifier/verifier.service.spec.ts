import { describe, it, expect, beforeEach } from 'vitest';
import { VerifierService } from './verifier.service';
import { ParseResult, VerifyResult } from '@/interfaces/apijson-request.interface';

describe('VerifierService', () => {
  let service: VerifierService;

  beforeEach(() => {
    service = new VerifierService();
  });

  describe('verify - Overall Verification', () => {
    it('should verify valid parse result successfully', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
      expect(result.tables).toBeDefined();
      expect(result.directives).toBeDefined();
      expect(result.original).toBe(parseResult);
    });

    it('should verify parse result with errors', async () => {
      const parseResult: ParseResult = {
        tables: {
          'Invalid Table': {
            name: 'Invalid Table',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]).toContain('表名');
    });

    it('should verify parse result with warnings', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: ['name+'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.warnings).toBeDefined();
      expect(result.errors).toEqual([]);
    });

    it('should verify parse result with directives', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {
          '@method': 'GET',
          '@page': 0,
        },
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.directives).toBeDefined();
      expect(result.directives['@method']).toBeDefined();
      expect(result.directives['@page']).toBeDefined();
    });

    it('should verify parse result with invalid directives', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {
          '@invalidDirective': 'value',
        },
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors.some(e => e.includes('指令名'))).toBe(true);
    });
  });

  describe('verifyTableQuery - Table Query Verification', () => {
    it('should verify valid table query', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id', 'name', 'age'],
        where: { id: 1, 'age>': 18 },
        joins: [],
        group: [],
        having: {},
        order: ['name+'],
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
      expect(result.table).toBe('User');
      expect(result.columns).toEqual(['id', 'name', 'age']);
    });

    it('should verify table query with invalid table name', async () => {
      const tableQuery = {
        name: 'Invalid@Table',
        operation: 'GET',
        columns: ['id'],
        where: {},
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('Invalid@Table', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('表名 "Invalid@Table" 无效');
    });

    it('should verify table query with invalid columns', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: 123 as any,
        where: {},
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('列必须为数组或字符串');
    });

    it('should verify table query with invalid where', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id'],
        where: 'invalid' as any,
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('条件必须为对象');
    });

    it('should verify table query with invalid joins', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id'],
        where: {},
        joins: 'invalid' as any,
        group: [],
        having: {},
        order: [],
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('连接必须为数组');
    });

    it('should verify table query with invalid limit', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id'],
        where: {},
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: -1,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('限制必须为正数');
    });

    it('should verify table query with invalid offset', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id'],
        where: {},
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: 10,
        offset: -1,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('偏移必须为非负数');
    });

    it('should verify table query with too large limit', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: ['id'],
        where: {},
        joins: [],
        group: [],
        having: {},
        order: [],
        limit: 2000,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('限制不能超过1000');
    });
  });

  describe('verifyDirective - Directive Verification', () => {
    it('should verify valid directive', async () => {
      const directive = {
        name: '@method',
        value: 'GET',
      };

      const result = await service['verifyDirective']('@method', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
      expect(result.name).toBe('@method');
      expect(result.value).toBe('GET');
    });

    it('should verify directive with invalid name', async () => {
      const directive = {
        name: 'invalidDirective',
        value: 'value',
      };

      const result = await service['verifyDirective']('invalidDirective', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令名 "invalidDirective" 无效');
    });

    it('should verify directive without @ prefix', async () => {
      const directive = {
        name: 'method',
        value: 'GET',
      };

      const result = await service['verifyDirective']('method', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令名 "method" 无效');
    });

    it('should verify @method directive with valid value', async () => {
      const directive = {
        name: '@method',
        value: 'GET',
      };

      const result = await service['verifyDirective']('@method', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @method directive with invalid value', async () => {
      const directive = {
        name: '@method',
        value: 'INVALID',
      };

      const result = await service['verifyDirective']('@method', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令 "@method" 的值 "INVALID" 无效');
    });

    it('should verify @page directive with valid value', async () => {
      const directive = {
        name: '@page',
        value: 0,
      };

      const result = await service['verifyDirective']('@page', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @page directive with invalid value', async () => {
      const directive = {
        name: '@page',
        value: 'invalid' as any,
      };

      const result = await service['verifyDirective']('@page', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令 "@page" 的值 "invalid" 必须为数字');
    });

    it('should verify @cache directive with boolean value', async () => {
      const directive = {
        name: '@cache',
        value: true,
      };

      const result = await service['verifyDirective']('@cache', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @cache directive with object value', async () => {
      const directive = {
        name: '@cache',
        value: { enabled: true, expireTime: 60 },
      };

      const result = await service['verifyDirective']('@cache', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @cache directive with invalid value', async () => {
      const directive = {
        name: '@cache',
        value: 'invalid' as any,
      };

      const result = await service['verifyDirective']('@cache', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令 "@cache" 的值 "invalid" 无效');
    });

    it('should verify @order directive with valid value', async () => {
      const directive = {
        name: '@order',
        value: 'name+,age-',
      };

      const result = await service['verifyDirective']('@order', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @order directive with invalid value', async () => {
      const directive = {
        name: '@order',
        value: 123 as any,
      };

      const result = await service['verifyDirective']('@order', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令 "@order" 的值 "123" 无效');
    });

    it('should verify @group directive with valid value', async () => {
      const directive = {
        name: '@group',
        value: 'department,role',
      };

      const result = await service['verifyDirective']('@group', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
    });

    it('should verify @group directive with invalid value', async () => {
      const directive = {
        name: '@group',
        value: 123 as any,
      };

      const result = await service['verifyDirective']('@group', directive);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('指令 "@group" 的值 "123" 无效');
    });
  });

  describe('isValidTableName - Table Name Validation', () => {
    it('should validate valid table name', () => {
      const result = service['isValidTableName']('User');

      expect(result).toBe(true);
    });

    it('should validate table name starting with letter', () => {
      const result = service['isValidTableName']('User123');

      expect(result).toBe(true);
    });

    it('should reject table name starting with @', () => {
      const result = service['isValidTableName']('@User');

      expect(result).toBe(false);
    });

    it('should reject table name with special characters', () => {
      const result = service['isValidTableName']('User<>');

      expect(result).toBe(false);
    });

    it('should reject table name with colon', () => {
      const result = service['isValidTableName']('User:Table');

      expect(result).toBe(false);
    });

    it('should reject table name with pipe', () => {
      const result = service['isValidTableName']('User|Table');

      expect(result).toBe(false);
    });

    it('should reject table name with question mark', () => {
      const result = service['isValidTableName']('User?Table');

      expect(result).toBe(false);
    });

    it('should reject table name with asterisk', () => {
      const result = service['isValidTableName']('User*Table');

      expect(result).toBe(false);
    });

    it('should reject table name with backslash', () => {
      const result = service['isValidTableName']('User\\Table');

      expect(result).toBe(false);
    });

    it('should reject table name with forward slash', () => {
      const result = service['isValidTableName']('User/Table');

      expect(result).toBe(false);
    });

    it('should reject table name with null character', () => {
      const result = service['isValidTableName']('User\x00Table');

      expect(result).toBe(false);
    });

    it('should reject table name too long', () => {
      const longName = 'A'.repeat(65);
      const result = service['isValidTableName'](longName);

      expect(result).toBe(false);
    });

    it('should reject non-string table name', () => {
      const result = service['isValidTableName'](123 as any);

      expect(result).toBe(false);
    });
  });

  describe('verifyColumns - Column Verification', () => {
    it('should validate valid column array', async () => {
      const columns = ['id', 'name', 'age'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toEqual([]);
    });

    it('should validate valid column string', async () => {
      const columns = 'id,name,age';

      const errors = await service['verifyColumns'](columns);

      expect(errors).toEqual([]);
    });

    it('should reject non-array non-string columns', async () => {
      const columns = 123 as any;

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列必须为数组或字符串');
    });

    it('should reject non-string column in array', async () => {
      const columns = ['id', 123, 'name'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "123" 必须为字符串');
    });

    it('should reject column with special characters', async () => {
      const columns = ['id', 'name<>'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name<>" 包含非法字符');
    });

    it('should reject column with colon', async () => {
      const columns = ['id', 'name:column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name:column" 包含非法字符');
    });

    it('should reject column with pipe', async () => {
      const columns = ['id', 'name|column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name|column" 包含非法字符');
    });

    it('should reject column with question mark', async () => {
      const columns = ['id', 'name?column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name?column" 包含非法字符');
    });

    it('should reject column with asterisk', async () => {
      const columns = ['id', 'name*column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name*column" 包含非法字符');
    });

    it('should reject column with backslash', async () => {
      const columns = ['id', 'name\\column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name\\column" 包含非法字符');
    });

    it('should reject column with forward slash', async () => {
      const columns = ['id', 'name/column'];

      const errors = await service['verifyColumns'](columns);

      expect(errors).toContain('列 "name/column" 包含非法字符');
    });
  });

  describe('verifyWhere - WHERE Condition Verification', () => {
    it('should validate valid where object', async () => {
      const where = { id: 1, 'age>': 18, 'name~': '张' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toEqual([]);
    });

    it('should reject non-object where', async () => {
      const where = 'invalid' as any;

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件必须为对象');
    });

    it('should reject null where', async () => {
      const where = null;

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件必须为对象');
    });

    it('should reject condition key with special characters', async () => {
      const where = { 'id<>': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id<>" 无效');
    });

    it('should reject condition key with colon', async () => {
      const where = { 'id:column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id:column" 无效');
    });

    it('should reject condition key with pipe', async () => {
      const where = { 'id|column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id|column" 无效');
    });

    it('should reject condition key with question mark', async () => {
      const where = { 'id?column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id?column" 无效');
    });

    it('should reject condition key with asterisk', async () => {
      const where = { 'id*column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id*column" 无效');
    });

    it('should reject condition key with backslash', async () => {
      const where = { 'id\\column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id\\column" 无效');
    });

    it('should reject condition key with forward slash', async () => {
      const where = { 'id/column': 1 };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件键 "id/column" 无效');
    });

    it('should reject condition value with special characters', async () => {
      const where = { 'id': 'value<>' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value<>" 无效');
    });

    it('should reject condition value with colon', async () => {
      const where = { 'id': 'value:value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value:value" 无效');
    });

    it('should reject condition value with pipe', async () => {
      const where = { 'id': 'value|value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value|value" 无效');
    });

    it('should reject condition value with question mark', async () => {
      const where = { 'id': 'value?value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value?value" 无效');
    });

    it('should reject condition value with asterisk', async () => {
      const where = { 'id': 'value*value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value*value" 无效');
    });

    it('should reject condition value with backslash', async () => {
      const where = { 'id': 'value\\value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value\\value" 无效');
    });

    it('should reject condition value with forward slash', async () => {
      const where = { 'id': 'value/value' };

      const errors = await service['verifyWhere'](where);

      expect(errors).toContain('条件值 "value/value" 无效');
    });
  });

  describe('verifyJoins - JOIN Verification', () => {
    it('should validate valid joins array', async () => {
      const joins = [
        { type: '&', table: 'Moment', on: 'User.id = Moment.userId' },
        { type: '<', table: 'Comment', on: 'Moment.id = Comment.momentId' },
      ];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toEqual([]);
    });

    it('should reject non-array joins', async () => {
      const joins = 'invalid' as any;

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接必须为数组');
    });

    it('should reject non-object join', async () => {
      const joins = ['invalid' as any];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接必须为对象');
    });

    it('should reject join without table', async () => {
      const joins = [{ type: '&', on: 'User.id = Moment.userId' }];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接缺少表名');
    });

    it('should reject join with invalid table name', async () => {
      const joins = [{ type: '&', table: '@Invalid', on: 'User.id = Moment.userId' }];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接表名 "@Invalid" 无效');
    });

    it('should reject join with invalid type', async () => {
      const joins = [{ type: 'INVALID', table: 'Moment', on: 'User.id = Moment.userId' }];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接类型 "INVALID" 无效');
    });

    it('should reject join without on', async () => {
      const joins = [{ type: '&', table: 'Moment' }];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接条件缺失');
    });

    it('should reject join with invalid on type', async () => {
      const joins = [{ type: '&', table: 'Moment', on: 123 as any }];

      const errors = await service['verifyJoins'](joins);

      expect(errors).toContain('连接条件无效');
    });
  });

  describe('verifyGroup - GROUP BY Verification', () => {
    it('should validate valid group array', async () => {
      const group = ['department', 'role'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toEqual([]);
    });

    it('should validate valid group string', async () => {
      const group = 'department,role';

      const errors = await service['verifyGroup'](group);

      expect(errors).toEqual([]);
    });

    it('should reject non-array non-string group', async () => {
      const group = 123 as any;

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组必须为数组或字符串');
    });

    it('should reject non-string column in array', async () => {
      const group = ['department', 123];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "123" 必须为字符串');
    });

    it('should reject column with special characters', async () => {
      const group = ['department<>'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department<>" 包含非法字符');
    });

    it('should reject column with colon', async () => {
      const group = ['department:column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department:column" 包含非法字符');
    });

    it('should reject column with pipe', async () => {
      const group = ['department|column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department|column" 包含非法字符');
    });

    it('should reject column with question mark', async () => {
      const group = ['department?column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department?column" 包含非法字符');
    });

    it('should reject column with asterisk', async () => {
      const group = ['department*column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department*column" 包含非法字符');
    });

    it('should reject column with backslash', async () => {
      const group = ['department\\column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department\\column" 包含非法字符');
    });

    it('should reject column with forward slash', async () => {
      const group = ['department/column'];

      const errors = await service['verifyGroup'](group);

      expect(errors).toContain('分组 "department/column" 包含非法字符');
    });
  });

  describe('verifyHaving - HAVING Verification', () => {
    it('should validate valid having object', async () => {
      const having = { 'COUNT(*)>': 5, 'SUM(age)<': 100 };

      const errors = await service['verifyHaving'](having);

      expect(errors).toEqual([]);
    });

    it('should reject non-object having', async () => {
      const having = 'invalid' as any;

      const errors = await service['verifyHaving'](having);

      expect(errors).toContain('分组条件必须为对象');
    });

    it('should reject null having', async () => {
      const having = null;

      const errors = await service['verifyHaving'](having);

      expect(errors).toContain('分组条件必须为对象');
    });

    it('should reject condition key with special characters', async () => {
      const having = { 'COUNT(*)<>': 5 };

      const errors = await service['verifyHaving'](having);

      expect(errors).toContain('分组条件键 "COUNT(*)<>" 无效');
    });

    it('should reject condition value with special characters', async () => {
      const having = { 'COUNT(*)': 'value<>' };

      const errors = await service['verifyHaving'](having);

      expect(errors).toContain('分组条件值 "value<>" 无效');
    });
  });

  describe('verifyOrder - ORDER BY Verification', () => {
    it('should validate valid order array', async () => {
      const order = ['name+', 'age-'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toEqual([]);
    });

    it('should validate valid order string', async () => {
      const order = 'name+,age-';

      const errors = await service['verifyOrder'](order);

      expect(errors).toEqual([]);
    });

    it('should reject non-array non-string order', async () => {
      const order = 123 as any;

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序必须为数组或字符串');
    });

    it('should reject non-string column in array', async () => {
      const order = [123, 'name+'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "123" 必须为字符串');
    });

    it('should reject column with special characters', async () => {
      const order = ['name<>'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name<>" 包含非法字符');
    });

    it('should reject column with colon', async () => {
      const order = ['name:column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name:column" 包含非法字符');
    });

    it('should reject column with pipe', async () => {
      const order = ['name|column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name|column" 包含非法字符');
    });

    it('should reject column with question mark', async () => {
      const order = ['name?column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name?column" 包含非法字符');
    });

    it('should reject column with asterisk', async () => {
      const order = ['name*column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name*column" 包含非法字符');
    });

    it('should reject column with backslash', async () => {
      const order = ['name\\column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name\\column" 包含非法字符');
    });

    it('should reject column with forward slash', async () => {
      const order = ['name/column'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "name/column" 包含非法字符');
    });

    it('should reject order with missing column name', async () => {
      const order = ['+'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "+" 缺少列名');
    });

    it('should reject order with missing column name', async () => {
      const order = ['-'];

      const errors = await service['verifyOrder'](order);

      expect(errors).toContain('排序 "-" 缺少列名');
    });
  });

  describe('verifyLimit - LIMIT Verification', () => {
    it('should validate valid limit', async () => {
      const limit = 10;

      const errors = await service['verifyLimit'](limit);

      expect(errors).toEqual([]);
    });

    it('should reject non-number limit', async () => {
      const limit = '10' as any;

      const errors = await service['verifyLimit'](limit);

      expect(errors).toContain('限制必须为数字');
    });

    it('should reject zero limit', async () => {
      const limit = 0;

      const errors = await service['verifyLimit'](limit);

      expect(errors).toContain('限制必须为正数');
    });

    it('should reject negative limit', async () => {
      const limit = -10;

      const errors = await service['verifyLimit'](limit);

      expect(errors).toContain('限制必须为正数');
    });

    it('should reject limit over 1000', async () => {
      const limit = 2000;

      const errors = await service['verifyLimit'](limit);

      expect(errors).toContain('限制不能超过1000');
    });
  });

  describe('verifyOffset - OFFSET Verification', () => {
    it('should validate valid offset', async () => {
      const offset = 10;

      const errors = await service['verifyOffset'](offset);

      expect(errors).toEqual([]);
    });

    it('should validate zero offset', async () => {
      const offset = 0;

      const errors = await service['verifyOffset'](offset);

      expect(errors).toEqual([]);
    });

    it('should reject non-number offset', async () => {
      const offset = '10' as any;

      const errors = await service['verifyOffset'](offset);

      expect(errors).toContain('偏移必须为数字');
    });

    it('should reject negative offset', async () => {
      const offset = -10;

      const errors = await service['verifyOffset'](offset);

      expect(errors).toContain('偏移必须为非负数');
    });
  });

  describe('isValidConditionKey - Condition Key Validation', () => {
    it('should validate valid condition key', () => {
      const result = service['isValidConditionKey']('id');

      expect(result).toBe(true);
    });

    it('should validate condition key with operator', () => {
      const result = service['isValidConditionKey']('id>');

      expect(result).toBe(true);
    });

    it('should validate condition key with multiple operators', () => {
      const result = service['isValidConditionKey']('id{}');

      expect(result).toBe(true);
    });

    it('should reject condition key with special characters', () => {
      const result = service['isValidConditionKey']('id<>');

      expect(result).toBe(false);
    });

    it('should reject condition key with colon', () => {
      const result = service['isValidConditionKey']('id:column');

      expect(result).toBe(false);
    });

    it('should reject condition key with pipe', () => {
      const result = service['isValidConditionKey']('id|column');

      expect(result).toBe(false);
    });

    it('should reject condition key with question mark', () => {
      const result = service['isValidConditionKey']('id?column');

      expect(result).toBe(false);
    });

    it('should reject condition key with asterisk', () => {
      const result = service['isValidConditionKey']('id*column');

      expect(result).toBe(false);
    });

    it('should reject condition key with backslash', () => {
      const result = service['isValidConditionKey']('id\\column');

      expect(result).toBe(false);
    });

    it('should reject condition key with forward slash', () => {
      const result = service['isValidConditionKey']('id/column');

      expect(result).toBe(false);
    });

    it('should reject non-string condition key', () => {
      const result = service['isValidConditionKey'](123 as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidJoinType - JOIN Type Validation', () => {
    it('should validate INNER join type', () => {
      const result = service['isValidJoinType']('INNER');

      expect(result).toBe(true);
    });

    it('should validate LEFT join type', () => {
      const result = service['isValidJoinType']('LEFT');

      expect(result).toBe(true);
    });

    it('should validate RIGHT join type', () => {
      const result = service['isValidJoinType']('RIGHT');

      expect(result).toBe(true);
    });

    it('should validate FULL join type', () => {
      const result = service['isValidJoinType']('FULL');

      expect(result).toBe(true);
    });

    it('should validate lowercase join type', () => {
      const result = service['isValidJoinType']('inner');

      expect(result).toBe(true);
    });

    it('should reject invalid join type', () => {
      const result = service['isValidJoinType']('INVALID');

      expect(result).toBe(false);
    });

    it('should reject non-string join type', () => {
      const result = service['isValidJoinType'](123 as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidJoinOn - JOIN ON Validation', () => {
    it('should validate string join on', () => {
      const result = service['isValidJoinOn']('User.id = Moment.userId');

      expect(result).toBe(true);
    });

    it('should validate object join on', () => {
      const result = service['isValidJoinOn']({ column: 'User.id', operator: '=', value: 'Moment.userId' });

      expect(result).toBe(true);
    });

    it('should reject null join on', () => {
      const result = service['isValidJoinOn'](null);

      expect(result).toBe(false);
    });

    it('should reject number join on', () => {
      const result = service['isValidJoinOn'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject array join on', () => {
      const result = service['isValidJoinOn']([1, 2, 3] as any);

      expect(result).toBe(false);
    });

    it('should reject boolean join on', () => {
      const result = service['isValidJoinOn'](true as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidMethod - Method Validation', () => {
    it('should validate GET method', () => {
      const result = service['isValidMethod']('GET');

      expect(result).toBe(true);
    });

    it('should validate POST method', () => {
      const result = service['isValidMethod']('POST');

      expect(result).toBe(true);
    });

    it('should validate PUT method', () => {
      const result = service['isValidMethod']('PUT');

      expect(result).toBe(true);
    });

    it('should validate DELETE method', () => {
      const result = service['isValidMethod']('DELETE');

      expect(result).toBe(true);
    });

    it('should validate PATCH method', () => {
      const result = service['isValidMethod']('PATCH');

      expect(result).toBe(true);
    });

    it('should validate lowercase method', () => {
      const result = service['isValidMethod']('get');

      expect(result).toBe(true);
    });

    it('should reject invalid method', () => {
      const result = service['isValidMethod']('INVALID');

      expect(result).toBe(false);
    });

    it('should reject non-string method', () => {
      const result = service['isValidMethod'](123 as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidNumber - Number Validation', () => {
    it('should validate positive number', () => {
      const result = service['isValidNumber'](10);

      expect(result).toBe(true);
    });

    it('should validate zero', () => {
      const result = service['isValidNumber'](0);

      expect(result).toBe(true);
    });

    it('should validate negative number', () => {
      const result = service['isValidNumber'](-10);

      expect(result).toBe(true);
    });

    it('should validate decimal number', () => {
      const result = service['isValidNumber'](10.5);

      expect(result).toBe(true);
    });

    it('should reject NaN', () => {
      const result = service['isValidNumber'](NaN);

      expect(result).toBe(false);
    });

    it('should reject non-number', () => {
      const result = service['isValidNumber']('10' as any);

      expect(result).toBe(false);
    });

    it('should reject null', () => {
      const result = service['isValidNumber'](null as any);

      expect(result).toBe(false);
    });

    it('should reject undefined', () => {
      const result = service['isValidNumber'](undefined as any);

      expect(result).toBe(false);
    });

    it('should reject object', () => {
      const result = service['isValidNumber']({} as any);

      expect(result).toBe(false);
    });

    it('should reject array', () => {
      const result = service['isValidNumber']([1, 2, 3] as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidCache - Cache Validation', () => {
    it('should validate boolean cache', () => {
      const result = service['isValidCache'](true);

      expect(result).toBe(true);
    });

    it('should validate false cache', () => {
      const result = service['isValidCache'](false);

      expect(result).toBe(true);
    });

    it('should validate object cache', () => {
      const result = service['isValidCache']({ enabled: true, expireTime: 60 });

      expect(result).toBe(true);
    });

    it('should reject string cache', () => {
      const result = service['isValidCache']('true' as any);

      expect(result).toBe(false);
    });

    it('should reject number cache', () => {
      const result = service['isValidCache'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject null cache', () => {
      const result = service['isValidCache'](null as any);

      expect(result).toBe(false);
    });

    it('should reject undefined cache', () => {
      const result = service['isValidCache'](undefined as any);

      expect(result).toBe(false);
    });

    it('should reject array cache', () => {
      const result = service['isValidCache']([1, 2, 3] as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidOrder - Order Validation', () => {
    it('should validate order array', () => {
      const result = service['isValidOrder'](['name+', 'age-']);

      expect(result).toBe(true);
    });

    it('should validate order string', () => {
      const result = service['isValidOrder']('name+,age-');

      expect(result).toBe(true);
    });

    it('should reject non-array non-string order', () => {
      const result = service['isValidOrder'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject null order', () => {
      const result = service['isValidOrder'](null as any);

      expect(result).toBe(false);
    });

    it('should reject undefined order', () => {
      const result = service['isValidOrder'](undefined as any);

      expect(result).toBe(false);
    });

    it('should reject number order', () => {
      const result = service['isValidOrder'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject object order', () => {
      const result = service['isValidOrder']({} as any);

      expect(result).toBe(false);
    });
  });

  describe('isValidGroup - Group Validation', () => {
    it('should validate group array', () => {
      const result = service['isValidGroup'](['department', 'role']);

      expect(result).toBe(true);
    });

    it('should validate group string', () => {
      const result = service['isValidGroup']('department,role');

      expect(result).toBe(true);
    });

    it('should reject non-array non-string group', () => {
      const result = service['isValidGroup'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject null group', () => {
      const result = service['isValidGroup'](null as any);

      expect(result).toBe(false);
    });

    it('should reject undefined group', () => {
      const result = service['isValidGroup'](undefined as any);

      expect(result).toBe(false);
    });

    it('should reject number group', () => {
      const result = service['isValidGroup'](123 as any);

      expect(result).toBe(false);
    });

    it('should reject object group', () => {
      const result = service['isValidGroup']({} as any);

      expect(result).toBe(false);
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle complex valid parse result', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name', 'age', 'email'],
            where: { id: 1, 'age>': 18, 'status': 'active' },
            joins: [
              { type: '&', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: ['department'],
            having: { 'COUNT(*)>': 5 },
            order: ['name+', 'age-'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {
          '@method': 'GET',
          '@page': 0,
          '@cache': { enabled: true, expireTime: 60 },
        },
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.tables.User.valid).toBe(true);
      expect(result.tables.User.columns).toEqual(['id', 'name', 'age', 'email']);
      expect(result.tables.User.joins).toHaveLength(1);
      expect(result.tables.User.group).toEqual(['department']);
      expect(result.tables.User.having).toEqual({ 'COUNT(*)>': 5 });
      expect(result.tables.User.order).toEqual(['name+', 'age-']);
      expect(result.tables.User.limit).toBe(10);
      expect(result.tables.User.offset).toBe(0);
      expect(result.directives['@method'].valid).toBe(true);
      expect(result.directives['@page'].valid).toBe(true);
      expect(result.directives['@cache'].valid).toBe(true);
    });

    it('should handle parse result with multiple tables', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
          Moment: {
            name: 'Moment',
            operation: 'GET',
            columns: ['id', 'content'],
            where: { userId: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 20,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.tables.User.valid).toBe(true);
      expect(result.tables.Moment.valid).toBe(true);
    });

    it('should handle parse result with multiple errors', async () => {
      const parseResult: ParseResult = {
        tables: {
          '@InvalidTable': {
            name: '@InvalidTable',
            operation: 'GET',
            columns: ['id'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
          'Another@Invalid': {
            name: 'Another@Invalid',
            operation: 'GET',
            columns: ['id'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(1);
    });

    it('should handle parse result with warnings', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: ['name+'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.warnings).toBeDefined();
      expect(result.errors).toEqual([]);
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty tables object', async () => {
      const parseResult: ParseResult = {
        tables: {},
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.tables).toEqual({});
      expect(result.directives).toEqual({});
    });

    it('should handle empty directives object', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.verify(parseResult);

      expect(result.valid).toBe(true);
      expect(result.directives).toEqual({});
    });

    it('should preserve original parse result', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: { test: 'original' },
      };

      const result = await service.verify(parseResult);

      expect(result.original).toBe(parseResult);
    });

    it('should handle table query with undefined fields', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: undefined as any,
        where: {},
        joins: undefined as any,
        group: undefined as any,
        having: undefined as any,
        order: undefined as any,
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should handle table query with null fields', async () => {
      const tableQuery = {
        name: 'User',
        operation: 'GET',
        columns: null as any,
        where: null as any,
        joins: null as any,
        group: null as any,
        having: null as any,
        order: null as any,
        limit: 10,
        offset: 0,
      };

      const result = await service['verifyTableQuery']('User', tableQuery);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should handle directive with undefined value', async () => {
      const directive = {
        name: '@method',
        value: undefined as any,
      };

      const result = await service['verifyDirective']('@method', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });

    it('should handle directive with null value', async () => {
      const directive = {
        name: '@method',
        value: null as any,
      };

      const result = await service['verifyDirective']('@method', directive);

      expect(result.valid).toBe(true);
      expect(result.errors).toEqual([]);
      expect(result.warnings).toEqual([]);
    });
  });
});
