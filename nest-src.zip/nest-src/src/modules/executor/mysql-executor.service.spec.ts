import { describe, it, expect, beforeEach, vi } from 'vitest';
import { MySQLExecutorService } from './mysql-executor.service';
import { BuildResult, ExecuteResult, Query } from '@/interfaces/apijson-request.interface';
import { DatabaseService } from '@/modules/database/database.service';
import { TableOperation } from '@/types/request-method.type';

const mockDatabaseService = {
  query: vi.fn(),
  executeTransaction: vi.fn(),
  testConnection: vi.fn(),
  getDatabaseVersion: vi.fn(),
  getDatabaseSize: vi.fn(),
} as any;

describe('MySQLExecutorService', () => {
  let service: MySQLExecutorService;

  beforeEach(() => {
    vi.clearAllMocks();
    service = new MySQLExecutorService(mockDatabaseService);
  });

  describe('execute - Basic Operations', () => {
    it('should execute SELECT query successfully', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT id, name FROM User WHERE id = ?',
          params: [1],
          operation: TableOperation.SELECT,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue([{ id: 1, name: '张三' }]);

      const result = await service.execute(buildResult);

      expect(result.data.User).toBeDefined();
      expect(result.data.User.data).toEqual([{ id: 1, name: '张三' }]);
    });

    it('should execute INSERT query successfully', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.INSERT,
          sql: 'INSERT INTO User (name) VALUES (?)',
          params: ['张三'],
          operation: TableOperation.INSERT,
          data: { name: '张三' },
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue({ insertId: 100 });

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([{ name: '张三', id: 100 }]);
      expect(result.data.User.total).toBe(1);
    });

    it('should execute UPDATE query successfully', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.UPDATE,
          sql: 'UPDATE User SET name = ? WHERE id = ?',
          params: ['李四', 1],
          operation: TableOperation.UPDATE,
          data: { name: '李四' },
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 1 });

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([{ name: '李四' }]);
      expect(result.data.User.total).toBe(1);
    });

    it('should execute DELETE query successfully', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.DELETE,
          sql: 'DELETE FROM User WHERE id = ?',
          params: [1],
          operation: TableOperation.DELETE,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 1 });

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([]);
      expect(result.data.User.total).toBe(1);
    });

    it('should execute COUNT query successfully', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.COUNT,
          sql: 'SELECT COUNT(*) AS count FROM User',
          params: [],
          operation: TableOperation.COUNT,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue([{ count: 100 }]);

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([{ count: 100 }]);
      expect(result.data.User.total).toBe(100);
    });
  });

  describe('executeSelect - Query Types', () => {
    it('should execute SELECT with DATA_ONLY', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        query: 0,
      };

      mockDatabaseService.query.mockResolvedValue([{ id: 1, name: '张三' }]);

      const result = await service['executeSelect'](query);

      expect(result.data).toEqual([{ id: 1, name: '张三' }]);
      expect(result.count).toBe(1);
      expect(result.total).toBe(0);
    });

    it('should execute SELECT with COUNT_ONLY', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        query: 1,
      };

      mockDatabaseService.query.mockResolvedValue([{ count: 100 }]);

      const result = await service['executeSelect'](query);

      expect(result.data).toEqual([]);
      expect(result.count).toBe(0);
      expect(result.total).toBe(100);
    });

    it('should execute SELECT with DATA_AND_COUNT', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        query: 2,
      };

      mockDatabaseService.query
        .mockResolvedValueOnce([{ count: 100 }])
        .mockResolvedValueOnce([{ id: 1, name: '张三' }]);

      const result = await service['executeSelect'](query);

      expect(result.data).toEqual([{ id: 1, name: '张三' }]);
      expect(result.count).toBe(1);
      expect(result.total).toBe(100);
    });
  });

  describe('executeInsert - Batch Operations', () => {
    it('should handle single row insert', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.INSERT,
        sql: 'INSERT INTO User (name) VALUES (?)',
        params: ['张三'],
        operation: TableOperation.INSERT,
        data: { name: '张三' },
      };

      mockDatabaseService.query.mockResolvedValue({ insertId: 100 });

      const result = await service['executeInsert'](query);

      expect(result.data).toEqual([{ name: '张三', id: 100 }]);
      expect(result.total).toBe(1);
    });

    it('should handle batch insert', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.INSERT,
        sql: 'INSERT INTO User (name) VALUES (?), (?)',
        params: ['张三', '李四'],
        operation: TableOperation.INSERT,
        data: [{ name: '张三' }, { name: '李四' }],
      };

      mockDatabaseService.query.mockResolvedValue({ insertId: 100 });

      const result = await service['executeInsert'](query);

      expect(result.data).toEqual([
        { name: '张三', id: 100 },
        { name: '李四', id: 101 },
      ]);
      expect(result.total).toBe(2);
    });
  });

  describe('executeUpdate - Batch Operations', () => {
    it('should handle single row update', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.UPDATE,
        sql: 'UPDATE User SET name = ? WHERE id = ?',
        params: ['李四', 1],
        operation: TableOperation.UPDATE,
        data: { name: '李四' },
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 1 });

      const result = await service['executeUpdate'](query);

      expect(result.data).toEqual([{ name: '李四' }]);
      expect(result.total).toBe(1);
    });

    it('should handle batch update', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.UPDATE,
        sql: 'UPDATE User SET name = ? WHERE id = ?',
        params: ['李四', 1],
        operation: TableOperation.UPDATE,
        data: [{ id: 1, name: '李四' }, { id: 2, name: '王五' }],
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 2 });

      const result = await service['executeUpdate'](query);

      expect(result.data).toEqual([{ id: 1, name: '李四' }, { id: 2, name: '王五' }]);
      expect(result.total).toBe(2);
    });
  });

  describe('executeDelete - Various Conditions', () => {
    it('should handle single row delete', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.DELETE,
        sql: 'DELETE FROM User WHERE id = ?',
        params: [1],
        operation: TableOperation.DELETE,
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 1 });

      const result = await service['executeDelete'](query);

      expect(result.data).toEqual([]);
      expect(result.total).toBe(1);
    });

    it('should handle multiple rows delete', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.DELETE,
        sql: 'DELETE FROM User WHERE id IN (?, ?, ?)',
        params: [1, 2, 3],
        operation: TableOperation.DELETE,
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 3 });

      const result = await service['executeDelete'](query);

      expect(result.data).toEqual([]);
      expect(result.total).toBe(3);
    });

    it('should handle delete with no affected rows', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.DELETE,
        sql: 'DELETE FROM User WHERE id = ?',
        params: [999],
        operation: TableOperation.DELETE,
      };

      mockDatabaseService.query.mockResolvedValue({ affectedRows: 0 });

      const result = await service['executeDelete'](query);

      expect(result.data).toEqual([]);
      expect(result.total).toBe(0);
    });
  });

  describe('executeCount - Different Result Formats', () => {
    it('should handle count in result', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.COUNT,
        sql: 'SELECT COUNT(*) AS count FROM User',
        params: [],
        operation: TableOperation.COUNT,
      };

      mockDatabaseService.query.mockResolvedValue([{ count: 100 }]);

      const result = await service['executeCount'](query);

      expect(result.data).toEqual([{ count: 100 }]);
      expect(result.total).toBe(100);
    });

    it('should handle COUNT(*) field in result', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.COUNT,
        sql: 'SELECT COUNT(*) FROM User',
        params: [],
        operation: TableOperation.COUNT,
      };

      mockDatabaseService.query.mockResolvedValue([{ 'COUNT(*)': 100 }]);

      const result = await service['executeCount'](query);

      expect(result.data).toEqual([{ 'COUNT(*)': 100 }]);
      expect(result.total).toBe(100);
    });

    it('should handle empty result', async () => {
      const query: Query = {
        table: 'User',
        type: TableOperation.COUNT,
        sql: 'SELECT COUNT(*) AS count FROM User',
        params: [],
        operation: TableOperation.COUNT,
      };

      mockDatabaseService.query.mockResolvedValue([]);

      const result = await service['executeCount'](query);

      expect(result.data).toEqual([]);
      expect(result.total).toBe(0);
    });
  });

  describe('executeTransaction - Transaction Management', () => {
    it('should execute transaction successfully', async () => {
      const queries: Query[] = [
        {
          table: 'User',
          type: TableOperation.INSERT,
          sql: 'INSERT INTO User (name) VALUES (?)',
          params: ['张三'],
          operation: TableOperation.INSERT,
        },
        {
          table: 'Moment',
          type: TableOperation.INSERT,
          sql: 'INSERT INTO Moment (content) VALUES (?)',
          params: ['测试动态'],
          operation: TableOperation.INSERT,
        },
      ];

      mockDatabaseService.executeTransaction.mockResolvedValue([
        { rows: [{ id: 1 }], affectedRows: 1, insertId: 1 },
        { rows: [{ id: 1 }], affectedRows: 1, insertId: 1 },
      ]);

      const results = await service['executeTransaction'](queries);

      expect(results).toHaveLength(2);
      expect(mockDatabaseService.executeTransaction).toHaveBeenCalled();
    });

    it('should handle transaction error', async () => {
      const queries: Query[] = [{
        table: 'User',
        type: TableOperation.INSERT,
        sql: 'INSERT INTO User (name) VALUES (?)',
        params: ['张三'],
        operation: TableOperation.INSERT,
      }];

      mockDatabaseService.executeTransaction.mockRejectedValue(
        new Error('Transaction failed')
      );

      await expect(service['executeTransaction'](queries)).rejects.toThrow(
        'Transaction failed'
      );
    });
  });

  describe('buildCountSql - SQL Transformation', () => {
    it('should build COUNT SQL from SELECT', () => {
      const sql = 'SELECT id, name, age FROM User WHERE age > 18';
      const countSql = service['buildCountSql'](sql);

      expect(countSql).toBe('SELECT COUNT(*) FROM User WHERE age > 18');
    });

    it('should handle SELECT with DISTINCT', () => {
      const sql = 'SELECT DISTINCT name FROM User';
      const countSql = service['buildCountSql'](sql);

      expect(countSql).toBe('SELECT COUNT(*) FROM User');
    });

    it('should handle SELECT with subquery', () => {
      const sql = 'SELECT * FROM User WHERE id IN (SELECT userId FROM Moment)';
      const countSql = service['buildCountSql'](sql);

      expect(countSql).toBe('SELECT COUNT(*) FROM User WHERE id IN (SELECT userId FROM Moment)');
    });

    it('should handle SELECT without FROM clause', () => {
      const sql = 'SELECT 1';
      const countSql = service['buildCountSql'](sql);

      expect(countSql).toBe('SELECT 1');
    });
  });

  describe('extractRows - Result Extraction', () => {
    it('should extract rows from array result', () => {
      const result = [
        { id: 1, name: '张三' },
        { id: 2, name: '李四' },
      ];

      const rows = service['extractRows'](result);

      expect(rows).toEqual(result);
    });

    it('should extract rows from result with rows property', () => {
      const result = {
        rows: [
          { id: 1, name: '张三' },
          { id: 2, name: '李四' },
        ],
      };

      const rows = service['extractRows'](result);

      expect(rows).toEqual(result.rows);
    });

    it('should return empty array for null result', () => {
      const rows = service['extractRows'](null);

      expect(rows).toEqual([]);
    });

    it('should return empty array for undefined result', () => {
      const rows = service['extractRows'](undefined);

      expect(rows).toEqual([]);
    });

    it('should return empty array for empty rows', () => {
      const result = { rows: [] };

      const rows = service['extractRows'](result);

      expect(rows).toEqual([]);
    });
  });

  describe('extractAffectedRows - Affected Rows Extraction', () => {
    it('should extract affectedRows from result', () => {
      const result = { affectedRows: 5 };

      const affectedRows = service['extractAffectedRows'](result);

      expect(affectedRows).toBe(5);
    });

    it('should extract rowCount from result', () => {
      const result = { rowCount: 3 };

      const affectedRows = service['extractAffectedRows'](result);

      expect(affectedRows).toBe(3);
    });

    it('should return 0 for null result', () => {
      const affectedRows = service['extractAffectedRows'](null);

      expect(affectedRows).toBe(0);
    });

    it('should return 0 for result without affected rows', () => {
      const result = { data: [] };

      const affectedRows = service['extractAffectedRows'](result);

      expect(affectedRows).toBe(0);
    });
  });

  describe('extractInsertId - Insert ID Extraction', () => {
    it('should extract insertId from result', () => {
      const result = { insertId: 100 };

      const insertId = service['extractInsertId'](result);

      expect(insertId).toBe(100);
    });

    it('should extract insertId from rows', () => {
      const result = { rows: [{ insertId: 100 }] };

      const insertId = service['extractInsertId'](result);

      expect(insertId).toBe(100);
    });

    it('should return 0 for null result', () => {
      const insertId = service['extractInsertId'](null);

      expect(insertId).toBe(0);
    });

    it('should return 0 for result without insertId', () => {
      const result = { data: [] };

      const insertId = service['extractInsertId'](result);

      expect(insertId).toBe(0);
    });
  });

  describe('extractCount - Count Extraction', () => {
    it('should extract count from result', () => {
      const result = [{ count: 100 }];

      const count = service['extractCount'](result);

      expect(count).toBe(100);
    });

    it('should extract COUNT(*) from result', () => {
      const result = [{ 'COUNT(*)': 100 }];

      const count = service['extractCount'](result);

      expect(count).toBe(100);
    });

    it('should find count key case-insensitively', () => {
      const result = [{ Count: 100 }];

      const count = service['extractCount'](result);

      expect(count).toBe(100);
    });

    it('should return 0 for empty result', () => {
      const result = [];

      const count = service['extractCount'](result);

      expect(count).toBe(0);
    });

    it('should return 0 for null result', () => {
      const count = service['extractCount'](null);

      expect(count).toBe(0);
    });

    it('should return 0 for result without count', () => {
      const result = [{ id: 1, name: '张三' }];

      const count = service['extractCount'](result);

      expect(count).toBe(0);
    });
  });

  describe('processJoinResults - JOIN Result Processing', () => {
    it('should process results with JOIN', () => {
      const data = [
        { id: 1, name: '张三', _joinTable: 'Moment', content: '测试动态' },
        { id: 2, name: '李四', _joinTable: 'Moment', content: '另一条动态' },
      ];

      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        joins: [{ type: '&', table: 'Moment', on: 'User.id = Moment.userId' }],
      };

      const processed = service['processJoinResults'](data, query);

      expect(processed).toHaveLength(2);
      expect(processed[0].Moment).toBeDefined();
      expect(processed[1].Moment).toBeDefined();
    });

    it('should return data unchanged when no joins', () => {
      const data = [
        { id: 1, name: '张三' },
        { id: 2, name: '李四' },
      ];

      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        joins: [],
      };

      const processed = service['processJoinResults'](data, query);

      expect(processed).toEqual(data);
    });

    it('should handle empty data', () => {
      const data: any[] = [];

      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        joins: [{ type: '&', table: 'Moment', on: 'User.id = Moment.userId' }],
      };

      const processed = service['processJoinResults'](data, query);

      expect(processed).toEqual([]);
    });

    it('should handle multiple JOINs', () => {
      const data = [
        {
          id: 1,
          name: '张三',
          _joinTable1: 'Moment',
          content: '测试动态',
          _joinTable2: 'Comment',
          comment: '测试评论',
        },
      ];

      const query: Query = {
        table: 'User',
        type: TableOperation.SELECT,
        sql: 'SELECT * FROM User',
        params: [],
        operation: TableOperation.SELECT,
        joins: [
          { type: '&', table: 'Moment', on: 'User.id = Moment.userId' },
          { type: '<', table: 'Comment', on: 'Moment.id = Comment.momentId' },
        ],
      };

      const processed = service['processJoinResults'](data, query);

      expect(processed[0].Moment).toBeDefined();
      expect(processed[0].Comment).toBeDefined();
    });
  });

  describe('testConnection - Database Connection', () => {
    it('should test database connection successfully', async () => {
      mockDatabaseService.testConnection.mockResolvedValue(true);

      const result = await service.testConnection();

      expect(result).toBe(true);
      expect(mockDatabaseService.testConnection).toHaveBeenCalled();
    });

    it('should handle connection test failure', async () => {
      mockDatabaseService.testConnection.mockRejectedValue(
        new Error('Connection failed')
      );

      const result = await service.testConnection();

      expect(result).toBe(false);
    });
  });

  describe('getDatabaseVersion - Database Version', () => {
    it('should get database version successfully', async () => {
      mockDatabaseService.getDatabaseVersion.mockResolvedValue('8.0.33');

      const version = await service.getDatabaseVersion();

      expect(version).toBe('8.0.33');
      expect(mockDatabaseService.getDatabaseVersion).toHaveBeenCalled();
    });

    it('should return unknown on error', async () => {
      mockDatabaseService.getDatabaseVersion.mockRejectedValue(
        new Error('Failed to get version')
      );

      const version = await service.getDatabaseVersion();

      expect(version).toBe('unknown');
    });
  });

  describe('getDatabaseSize - Database Size', () => {
    it('should get database size successfully', async () => {
      mockDatabaseService.getDatabaseSize.mockResolvedValue({
        database: 'test_db',
        size: 100.5,
        unit: 'MB',
      });

      const size = await service.getDatabaseSize();

      expect(size).toEqual({
        database: 'test_db',
        size: 100.5,
        unit: 'MB',
      });
      expect(mockDatabaseService.getDatabaseSize).toHaveBeenCalled();
    });

    it('should return default values on error', async () => {
      mockDatabaseService.getDatabaseSize.mockRejectedValue(
        new Error('Failed to get size')
      );

      const size = await service.getDatabaseSize();

      expect(size).toEqual({
        database: 'unknown',
        size: 0,
        unit: 'MB',
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle SELECT query error', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT * FROM NonExistentTable',
          params: [],
          operation: TableOperation.SELECT,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockRejectedValue(
        new Error('Table does not exist')
      );

      await expect(service.execute(buildResult)).rejects.toThrow(
        'Table does not exist'
      );
    });

    it('should handle INSERT query error', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.INSERT,
          sql: 'INSERT INTO User (name) VALUES (?)',
          params: ['张三'],
          operation: TableOperation.INSERT,
          data: { name: '张三' },
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockRejectedValue(
        new Error('Duplicate entry')
      );

      await expect(service.execute(buildResult)).rejects.toThrow(
        'Duplicate entry'
      );
    });

    it('should handle unsupported operation type', async () => {
      const query: Query = {
        table: 'User',
        type: 'INVALID' as any,
        sql: 'INVALID SQL',
        params: [],
        operation: 'INVALID' as any,
      };

      await expect(service['executeQuery'](query)).rejects.toThrow(
        '不支持的表操作类型: INVALID'
      );
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle query with all features', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT User.*, Moment.* FROM User INNER JOIN Moment ON User.id = Moment.userId WHERE User.age > ? ORDER BY User.name LIMIT ? OFFSET ?',
          params: [18, 10, 0],
          operation: TableOperation.SELECT,
          query: 2,
          joins: [{ type: '&', table: 'Moment', on: 'User.id = Moment.userId' }],
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query
        .mockResolvedValueOnce([{ count: 100 }])
        .mockResolvedValueOnce([
          { id: 1, name: '张三', age: 25, content: '测试动态' },
        ]);

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([
        { id: 1, name: '张三', age: 25, content: '测试动态' },
      ]);
      expect(result.data.User.count).toBe(1);
      expect(result.data.User.total).toBe(100);
    });

    it('should handle mixed operation types', async () => {
      const buildResult: BuildResult = {
        queries: [
          {
            table: 'User',
            type: TableOperation.INSERT,
            sql: 'INSERT INTO User (name) VALUES (?)',
            params: ['张三'],
            operation: TableOperation.INSERT,
            data: { name: '张三' },
          },
          {
            table: 'Moment',
            type: TableOperation.SELECT,
            sql: 'SELECT * FROM Moment WHERE userId = ?',
            params: [1],
            operation: TableOperation.SELECT,
          },
          {
            table: 'Comment',
            type: TableOperation.DELETE,
            sql: 'DELETE FROM Comment WHERE id = ?',
            params: [1],
            operation: TableOperation.DELETE,
          },
        ],
        directives: {},
        original: {},
      };

      mockDatabaseService.query
        .mockResolvedValueOnce({ insertId: 100 })
        .mockResolvedValueOnce([{ id: 1, content: '测试动态' }])
        .mockResolvedValueOnce({ affectedRows: 1 });

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([{ name: '张三', id: 100 }]);
      expect(result.data.Moment.data).toEqual([{ id: 1, content: '测试动态' }]);
      expect(result.data.Comment.data).toEqual([]);
      expect(result.data.Comment.total).toBe(1);
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty queries array', async () => {
      const buildResult: BuildResult = {
        queries: [],
        directives: {},
        original: {},
      };

      const result = await service.execute(buildResult);

      expect(result.data).toEqual({});
      expect(result.directives).toEqual({});
    });

    it('should handle query with no params', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT * FROM User',
          params: [],
          operation: TableOperation.SELECT,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue([]);

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([]);
    });

    it('should handle query with null params', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT * FROM User WHERE id IS NULL',
          params: [],
          operation: TableOperation.SELECT,
        }],
        directives: {},
        original: {},
      };

      mockDatabaseService.query.mockResolvedValue([]);

      const result = await service.execute(buildResult);

      expect(result.data.User.data).toEqual([]);
    });

    it('should preserve original build result', async () => {
      const buildResult: BuildResult = {
        queries: [{
          table: 'User',
          type: TableOperation.SELECT,
          sql: 'SELECT * FROM User',
          params: [],
          operation: TableOperation.SELECT,
        }],
        directives: { test: 'value' },
        original: { test: 'original' },
      };

      mockDatabaseService.query.mockResolvedValue([]);

      const result = await service.execute(buildResult);

      expect(result.original).toEqual(buildResult);
      expect(result.directives).toEqual({ test: 'value' });
    });
  });
});
