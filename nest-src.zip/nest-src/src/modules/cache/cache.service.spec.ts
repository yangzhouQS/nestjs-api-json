import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CacheService } from './cache.service';
import { ConfigService } from '@nestjs/config';

describe('CacheService', () => {
  let service: CacheService;
  let mockConfigService: any;

  beforeEach(() => {
    // Mock ConfigService
    mockConfigService = {
      get: vi.fn().mockReturnValue({
        type: 'memory',
        keyPrefix: 'apijson:',
        defaultTTL: 60000,
        maxSize: 1000,
      }),
    };

    service = new CacheService(mockConfigService as any);
  });

  afterEach(() => {
    // Clear cache after each test
    if (service) {
      service['cache'].clear();
    }
  });

  describe('get - Get Cache Value', () => {
    it('should get existing cache value', async () => {
      await service.set('testKey', 'testValue');

      const value = await service.get('testKey');

      expect(value).toBe('testValue');
    });

    it('should return null for non-existent key', async () => {
      const value = await service.get('nonExistentKey');

      expect(value).toBeNull();
    });

    it('should return null for expired cache', async () => {
      await service.set('testKey', 'testValue', 100);

      // Wait for cache to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const value = await service.get('testKey');

      expect(value).toBeNull();
    });

    it('should get value with custom TTL', async () => {
      await service.set('testKey', 'testValue', 60000);

      const value = await service.get('testKey');

      expect(value).toBe('testValue');
    });

    it('should get value with default TTL', async () => {
      await service.set('testKey', 'testValue');

      const value = await service.get('testKey');

      expect(value).toBe('testValue');
    });

    it('should get complex object value', async () => {
      const complexValue = { id: 1, name: 'test', nested: { value: 'data' } };
      await service.set('testKey', complexValue);

      const value = await service.get('testKey');

      expect(value).toEqual(complexValue);
    });

    it('should get array value', async () => {
      const arrayValue = [1, 2, 3, 4, 5];
      await service.set('testKey', arrayValue);

      const value = await service.get('testKey');

      expect(value).toEqual(arrayValue);
    });

    it('should get null value', async () => {
      await service.set('testKey', null);

      const value = await service.get('testKey');

      expect(value).toBeNull();
    });

    it('should get undefined value', async () => {
      await service.set('testKey', undefined);

      const value = await service.get('testKey');

      expect(value).toBeUndefined();
    });

    it('should get number value', async () => {
      await service.set('testKey', 123);

      const value = await service.get('testKey');

      expect(value).toBe(123);
    });

    it('should get boolean value', async () => {
      await service.set('testKey', true);

      const value = await service.get('testKey');

      expect(value).toBe(true);
    });

    it('should get string value', async () => {
      await service.set('testKey', 'testString');

      const value = await service.get('testKey');

      expect(value).toBe('testString');
    });
  });

  describe('set - Set Cache Value', () => {
    it('should set cache value successfully', async () => {
      await service.set('testKey', 'testValue');

      const value = await service.get('testKey');
      expect(value).toBe('testValue');
    });

    it('should set cache value with custom TTL', async () => {
      await service.set('testKey', 'testValue', 30000);

      const value = await service.get('testKey');
      expect(value).toBe('testValue');
    });

    it('should update existing cache value', async () => {
      await service.set('testKey', 'oldValue');
      await service.set('testKey', 'newValue');

      const value = await service.get('testKey');
      expect(value).toBe('newValue');
    });

    it('should set complex object value', async () => {
      const complexValue = { id: 1, name: 'test', nested: { value: 'data' } };
      await service.set('testKey', complexValue);

      const value = await service.get('testKey');
      expect(value).toEqual(complexValue);
    });

    it('should set array value', async () => {
      const arrayValue = [1, 2, 3, 4, 5];
      await service.set('testKey', arrayValue);

      const value = await service.get('testKey');
      expect(value).toEqual(arrayValue);
    });

    it('should set null value', async () => {
      await service.set('testKey', null);

      const value = await service.get('testKey');
      expect(value).toBeNull();
    });

    it('should set undefined value', async () => {
      await service.set('testKey', undefined);

      const value = await service.get('testKey');
      expect(value).toBeUndefined();
    });

    it('should set number value', async () => {
      await service.set('testKey', 123);

      const value = await service.get('testKey');
      expect(value).toBe(123);
    });

    it('should set boolean value', async () => {
      await service.set('testKey', true);

      const value = await service.get('testKey');
      expect(value).toBe(true);
    });

    it('should set string value', async () => {
      await service.set('testKey', 'testString');

      const value = await service.get('testKey');
      expect(value).toBe('testString');
    });

    it('should evict LRU when cache is full', async () => {
      // Set max size to 3
      mockConfigService.get.mockReturnValue({
        type: 'memory',
        keyPrefix: 'apijson:',
        defaultTTL: 60000,
        maxSize: 3,
      });

      const smallCacheService = new CacheService(mockConfigService as any);

      await smallCacheService.set('key1', 'value1');
      await smallCacheService.set('key2', 'value2');
      await smallCacheService.set('key3', 'value3');
      await smallCacheService.set('key4', 'value4');

      // key1 should be evicted
      const value1 = await smallCacheService.get('key1');
      const value4 = await smallCacheService.get('key4');

      expect(value1).toBeNull();
      expect(value4).toBe('value4');
    });
  });

  describe('del - Delete Cache Value', () => {
    it('should delete existing cache value', async () => {
      await service.set('testKey', 'testValue');
      await service.del('testKey');

      const value = await service.get('testKey');
      expect(value).toBeNull();
    });

    it('should handle deleting non-existent key', async () => {
      await service.del('nonExistentKey');

      // Should not throw error
      expect(async () => {
        await service.del('nonExistentKey');
      }).not.toThrow();
    });

    it('should delete multiple keys', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      await service.del('key1');
      await service.del('key2');

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBeNull();
      expect(value2).toBeNull();
      expect(value3).toBe('value3');
    });
  });

  describe('exists - Check Cache Existence', () => {
    it('should return true for existing key', async () => {
      await service.set('testKey', 'testValue');

      const exists = await service.exists('testKey');

      expect(exists).toBe(true);
    });

    it('should return false for non-existent key', async () => {
      const exists = await service.exists('nonExistentKey');

      expect(exists).toBe(false);
    });

    it('should return false for expired key', async () => {
      await service.set('testKey', 'testValue', 100);

      // Wait for cache to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const exists = await service.exists('testKey');

      expect(exists).toBe(false);
    });
  });

  describe('setnx - Set Only If Not Exists', () => {
    it('should set value when key does not exist', async () => {
      const result = await service.setnx('testKey', 'testValue');

      expect(result).toBe(1);
      const value = await service.get('testKey');
      expect(value).toBe('testValue');
    });

    it('should not set value when key exists', async () => {
      await service.set('testKey', 'oldValue');
      const result = await service.setnx('testKey', 'newValue');

      expect(result).toBe(0);
      const value = await service.get('testKey');
      expect(value).toBe('oldValue');
    });

    it('should set value with custom TTL when key does not exist', async () => {
      const result = await service.setnx('testKey', 'testValue', 30000);

      expect(result).toBe(1);
      const value = await service.get('testKey');
      expect(value).toBe('testValue');
    });
  });

  describe('getset - Get and Set', () => {
    it('should return old value and set new value', async () => {
      await service.set('testKey', 'oldValue');

      const oldValue = await service.getset('testKey', 'newValue');

      expect(oldValue).toBe('oldValue');
      const newValue = await service.get('testKey');
      expect(newValue).toBe('newValue');
    });

    it('should return null when key does not exist', async () => {
      const oldValue = await service.getset('testKey', 'newValue');

      expect(oldValue).toBeNull();
      const newValue = await service.get('testKey');
      expect(newValue).toBe('newValue');
    });

    it('should set value with custom TTL', async () => {
      await service.set('testKey', 'oldValue');

      const oldValue = await service.getset('testKey', 'newValue', 30000);

      expect(oldValue).toBe('oldValue');
      const newValue = await service.get('testKey');
      expect(newValue).toBe('newValue');
    });
  });

  describe('incr - Increment Cache Value', () => {
    it('should increment non-existent key', async () => {
      const result = await service.incr('testKey', 5);

      expect(result).toBe(5);
      const value = await service.get('testKey');
      expect(value).toBe(5);
    });

    it('should increment existing key', async () => {
      await service.set('testKey', 10);

      const result = await service.incr('testKey', 5);

      expect(result).toBe(15);
      const value = await service.get('testKey');
      expect(value).toBe(15);
    });

    it('should increment with default value', async () => {
      await service.set('testKey', 10);

      const result = await service.incr('testKey');

      expect(result).toBe(11);
    });

    it('should throw error for non-number value', async () => {
      await service.set('testKey', 'not-a-number');

      await expect(service.incr('testKey', 5)).rejects.toThrow('缓存值 "apijson:testKey" 不是数字');
    });

    it('should handle negative increment', async () => {
      await service.set('testKey', 10);

      const result = await service.incr('testKey', -5);

      expect(result).toBe(5);
    });

    it('should handle expired key', async () => {
      await service.set('testKey', 10, 100);

      // Wait for cache to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const result = await service.incr('testKey', 5);

      expect(result).toBe(5);
    });
  });

  describe('decr - Decrement Cache Value', () => {
    it('should decrement non-existent key', async () => {
      const result = await service.decr('testKey', 5);

      expect(result).toBe(5);
      const value = await service.get('testKey');
      expect(value).toBe(5);
    });

    it('should decrement existing key', async () => {
      await service.set('testKey', 10);

      const result = await service.decr('testKey', 5);

      expect(result).toBe(5);
      const value = await service.get('testKey');
      expect(value).toBe(5);
    });

    it('should decrement with default value', async () => {
      await service.set('testKey', 10);

      const result = await service.decr('testKey');

      expect(result).toBe(9);
    });

    it('should throw error for non-number value', async () => {
      await service.set('testKey', 'not-a-number');

      await expect(service.decr('testKey', 5)).rejects.toThrow('缓存值 "apijson:testKey" 不是数字');
    });

    it('should handle negative decrement', async () => {
      await service.set('testKey', 10);

      const result = await service.decr('testKey', -5);

      expect(result).toBe(15);
    });
  });

  describe('getStats - Get Cache Statistics', () => {
    it('should get cache statistics', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      const stats = await service.getStats();

      expect(stats.type).toBe('memory');
      expect(stats.size).toBe(3);
      expect(stats.maxSize).toBe(1000);
      expect(stats.totalSize).toBeGreaterThan(0);
      expect(stats.expiredCount).toBeGreaterThanOrEqual(0);
      expect(stats.hitRate).toBeGreaterThanOrEqual(0);
    });

    it('should get statistics for empty cache', async () => {
      const stats = await service.getStats();

      expect(stats.size).toBe(0);
      expect(stats.totalSize).toBe(0);
      expect(stats.expiredCount).toBe(0);
    });

    it('should count expired items', async () => {
      await service.set('key1', 'value1', 100);

      // Wait for cache to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const stats = await service.getStats();

      expect(stats.expiredCount).toBe(1);
    });
  });

  describe('clearExpired - Clear Expired Cache', () => {
    it('should clear expired cache items', async () => {
      await service.set('key1', 'value1', 100);
      await service.set('key2', 'value2', 60000);

      // Wait for key1 to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const count = await service.clearExpired();

      expect(count).toBe(1);
      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      expect(value1).toBeNull();
      expect(value2).toBe('value2');
    });

    it('should return 0 when no expired items', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');

      const count = await service.clearExpired();

      expect(count).toBe(0);
    });

    it('should return 0 for empty cache', async () => {
      const count = await service.clearExpired();

      expect(count).toBe(0);
    });
  });

  describe('flush - Clear All Cache', () => {
    it('should clear all cache items', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      await service.flush();

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBeNull();
      expect(value2).toBeNull();
      expect(value3).toBeNull();
    });

    it('should clear empty cache', async () => {
      await service.flush();

      // Should not throw error
      expect(async () => {
        await service.flush();
      }).not.toThrow();
    });
  });

  describe('keys - Get All Keys', () => {
    it('should get all cache keys', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      const keys = await service.keys();

      expect(keys).toHaveLength(3);
      expect(keys).toContain('key1');
      expect(keys).toContain('key2');
      expect(keys).toContain('key3');
    });

    it('should return empty array for empty cache', async () => {
      const keys = await service.keys();

      expect(keys).toEqual([]);
    });

    it('should not include keys without prefix', async () => {
      // Directly set a key without prefix
      service['cache'].set('noPrefixKey', { value: 'value', expiry: Date.now() + 60000 });

      const keys = await service.keys();

      expect(keys).not.toContain('noPrefixKey');
    });

    it('should return keys without prefix', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');

      const keys = await service.keys();

      expect(keys).toContain('key1');
      expect(keys).toContain('key2');
      expect(keys.every(key => !key.startsWith('apijson:'))).toBe(true);
    });
  });

  describe('mget - Batch Get', () => {
    it('should get multiple cache values', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      const values = await service.mget(['key1', 'key2', 'key3']);

      expect(values).toHaveLength(3);
      expect(values[0]).toBe('value1');
      expect(values[1]).toBe('value2');
      expect(values[2]).toBe('value3');
    });

    it('should return null for non-existent keys', async () => {
      await service.set('key1', 'value1');

      const values = await service.mget(['key1', 'key2', 'key3']);

      expect(values).toHaveLength(3);
      expect(values[0]).toBe('value1');
      expect(values[1]).toBeNull();
      expect(values[2]).toBeNull();
    });

    it('should handle empty key array', async () => {
      const values = await service.mget([]);

      expect(values).toEqual([]);
    });

    it('should handle single key', async () => {
      await service.set('key1', 'value1');

      const values = await service.mget(['key1']);

      expect(values).toHaveLength(1);
      expect(values[0]).toBe('value1');
    });
  });

  describe('mset - Batch Set', () => {
    it('should set multiple cache values', async () => {
      const keyValues = {
        key1: 'value1',
        key2: 'value2',
        key3: 'value3',
      };

      await service.mset(keyValues);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBe('value1');
      expect(value2).toBe('value2');
      expect(value3).toBe('value3');
    });

    it('should update existing keys', async () => {
      await service.set('key1', 'oldValue');

      const keyValues = {
        key1: 'newValue',
        key2: 'value2',
      };

      await service.mset(keyValues);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');

      expect(value1).toBe('newValue');
      expect(value2).toBe('value2');
    });

    it('should handle empty key values', async () => {
      await service.mset({});

      // Should not throw error
      expect(async () => {
        await service.mset({});
      }).not.toThrow();
    });

    it('should set values with custom TTL', async () => {
      const keyValues = {
        key1: 'value1',
        key2: 'value2',
      };

      await service.mset(keyValues, 30000);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');

      expect(value1).toBe('value1');
      expect(value2).toBe('value2');
    });
  });

  describe('mdel - Batch Delete', () => {
    it('should delete multiple cache values', async () => {
      await service.set('key1', 'value1');
      await service.set('key2', 'value2');
      await service.set('key3', 'value3');

      await service.mdel(['key1', 'key2']);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBeNull();
      expect(value2).toBeNull();
      expect(value3).toBe('value3');
    });

    it('should handle non-existent keys', async () => {
      await service.set('key1', 'value1');

      await service.mdel(['key1', 'key2', 'key3']);

      const value1 = await service.get('key1');

      expect(value1).toBeNull();
    });

    it('should handle empty key array', async () => {
      await service.mdel([]);

      // Should not throw error
      expect(async () => {
        await service.mdel([]);
      }).not.toThrow();
    });

    it('should handle single key', async () => {
      await service.set('key1', 'value1');

      await service.mdel(['key1']);

      const value1 = await service.get('key1');

      expect(value1).toBeNull();
    });
  });

  describe('Edge Cases', () => {
    it('should handle very long key', async () => {
      const longKey = 'a'.repeat(1000);

      await service.set(longKey, 'testValue');

      const value = await service.get(longKey);
      expect(value).toBe('testValue');
    });

    it('should handle very large value', async () => {
      const largeValue = 'a'.repeat(100000);

      await service.set('testKey', largeValue);

      const value = await service.get('testKey');
      expect(value).toBe(largeValue);
    });

    it('should handle special characters in key', async () => {
      const specialKey = 'key:with/special@characters#';

      await service.set(specialKey, 'testValue');

      const value = await service.get(specialKey);
      expect(value).toBe('testValue');
    });

    it('should handle unicode in key', async () => {
      const unicodeKey = '键值';

      await service.set(unicodeKey, 'testValue');

      const value = await service.get(unicodeKey);
      expect(value).toBe('testValue');
    });

    it('should handle unicode in value', async () => {
      const unicodeValue = '测试值';

      await service.set('testKey', unicodeValue);

      const value = await service.get('testKey');
      expect(value).toBe(unicodeValue);
    });

    it('should handle zero TTL', async () => {
      await service.set('testKey', 'testValue', 0);

      // Cache should be expired immediately
      const value = await service.get('testKey');
      expect(value).toBeNull();
    });

    it('should handle very large TTL', async () => {
      const largeTTL = 365 * 24 * 60 * 60 * 1000; // 1 year

      await service.set('testKey', 'testValue', largeTTL);

      const value = await service.get('testKey');
      expect(value).toBe('testValue');
    });

    it('should handle negative TTL', async () => {
      await service.set('testKey', 'testValue', -1000);

      // Cache should be expired immediately
      const value = await service.get('testKey');
      expect(value).toBeNull();
    });

    it('should handle concurrent operations', async () => {
      const operations = [
        service.set('key1', 'value1'),
        service.set('key2', 'value2'),
        service.set('key3', 'value3'),
        service.get('key1'),
        service.get('key2'),
        service.get('key3'),
      ];

      await Promise.all(operations);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBe('value1');
      expect(value2).toBe('value2');
      expect(value3).toBe('value3');
    });

    it('should handle rapid set and get', async () => {
      for (let i = 0; i < 100; i++) {
        await service.set(`key${i}`, `value${i}`);
      }

      for (let i = 0; i < 100; i++) {
        const value = await service.get(`key${i}`);
        expect(value).toBe(`value${i}`);
      }
    });

    it('should handle rapid set and delete', async () => {
      for (let i = 0; i < 100; i++) {
        await service.set(`key${i}`, `value${i}`);
      }

      for (let i = 0; i < 100; i++) {
        await service.del(`key${i}`);
        const value = await service.get(`key${i}`);
        expect(value).toBeNull();
      }
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle cache with mixed data types', async () => {
      const mixedData = {
        string: 'test',
        number: 123,
        boolean: true,
        null: null,
        array: [1, 2, 3],
        object: { nested: { value: 'data' } },
      };

      for (const [key, value] of Object.entries(mixedData)) {
        await service.set(key, value);
      }

      for (const [key, value] of Object.entries(mixedData)) {
        const cachedValue = await service.get(key);
        expect(cachedValue).toEqual(value);
      }
    });

    it('should handle cache expiration and cleanup', async () => {
      await service.set('key1', 'value1', 100);
      await service.set('key2', 'value2', 60000);
      await service.set('key3', 'value3', 100);

      // Wait for key1 and key3 to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const count = await service.clearExpired();

      expect(count).toBe(2);

      const value1 = await service.get('key1');
      const value2 = await service.get('key2');
      const value3 = await service.get('key3');

      expect(value1).toBeNull();
      expect(value2).toBe('value2');
      expect(value3).toBeNull();
    });

    it('should handle LRU eviction', async () => {
      // Set max size to 3
      mockConfigService.get.mockReturnValue({
        type: 'memory',
        keyPrefix: 'apijson:',
        defaultTTL: 60000,
        maxSize: 3,
      });

      const smallCacheService = new CacheService(mockConfigService as any);

      await smallCacheService.set('key1', 'value1');
      await smallCacheService.set('key2', 'value2');
      await smallCacheService.set('key3', 'value3');

      // Access key1 to make it recently used
      await smallCacheService.get('key1');

      // Add key4, should evict key2
      await smallCacheService.set('key4', 'value4');

      const value1 = await smallCacheService.get('key1');
      const value2 = await smallCacheService.get('key2');
      const value3 = await smallCacheService.get('key3');
      const value4 = await smallCacheService.get('key4');

      expect(value1).toBe('value1');
      expect(value2).toBeNull();
      expect(value3).toBe('value3');
      expect(value4).toBe('value4');
    });

    it('should handle atomic operations', async () => {
      // setnx should be atomic
      const result1 = await service.setnx('atomicKey', 'value1');
      const result2 = await service.setnx('atomicKey', 'value2');

      expect(result1).toBe(1);
      expect(result2).toBe(0);
      const value = await service.get('atomicKey');
      expect(value).toBe('value1');
    });

    it('should handle increment/decrement sequence', async () => {
      await service.set('counter', 0);

      const result1 = await service.incr('counter', 1);
      const result2 = await service.incr('counter', 2);
      const result3 = await service.decr('counter', 1);

      expect(result1).toBe(1);
      expect(result2).toBe(3);
      expect(result3).toBe(2);

      const value = await service.get('counter');
      expect(value).toBe(2);
    });
  });
});
