import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { DatabaseService } from './database.service';
import { ConfigService } from '@nestjs/config';
import * as mysql from 'mysql2/promise';

describe('DatabaseService', () => {
  let service: DatabaseService;
  let mockConfigService: any;
  let mockMySQLPool: any;

  beforeEach(() => {
    // Mock ConfigService
    mockConfigService = {
      get: vi.fn().mockReturnValue({
        type: 'mysql',
        host: 'localhost',
        port: 3306,
        user: 'root',
        password: 'password',
        database: 'test',
        connectionLimit: 10,
      }),
    };

    // Mock MySQL Pool
    mockMySQLPool = {
      query: vi.fn(),
      getConnection: vi.fn(),
      end: vi.fn(),
    };

    // Mock mysql.createPool
    vi.mock('mysql2/promise', () => ({
      createPool: vi.fn().mockReturnValue(mockMySQLPool),
    }));

    service = new DatabaseService(mockConfigService as any);
  });

  afterEach(async () => {
    if (service) {
      await service.close();
    }
  });

  describe('Initialization', () => {
    it('should initialize MySQL connection on module init', async () => {
      await service['onModuleInit']();

      expect(mysql.createPool).toHaveBeenCalledWith({
        host: 'localhost',
        port: 3306,
        user: 'root',
        password: 'password',
        database: 'test',
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        enableKeepAlive: true,
        keepAliveInitialDelay: 0,
      });
      expect(service['connection']).toBeDefined();
      expect(service['connection'].type).toBe('mysql');
    });

    it('should initialize PostgreSQL connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        host: 'localhost',
        port: 5432,
        user: 'postgres',
        password: 'password',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      expect(postgresService['connection']).toBeDefined();
      expect(postgresService['connection'].type).toBe('postgres');
    });

    it('should initialize SQLite connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      expect(sqliteService['connection']).toBeDefined();
      expect(sqliteService['connection'].type).toBe('sqlite');
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await expect(unsupportedService['onModuleInit']()).rejects.toThrow('不支持的数据库类型: unsupported');
    });

    it('should close connection on module destroy', async () => {
      await service['onModuleInit']();
      await service['onModuleDestroy']();

      expect(mockMySQLPool.end).toHaveBeenCalled();
    });
  });

  describe('query - Query Execution', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should execute MySQL query successfully', async () => {
      mockMySQLPool.query.mockResolvedValue([
        [{ id: 1, name: 'test' }],
        [{ name: 'id', type: 'int' }],
      ]);

      const result = await service.query('SELECT * FROM User WHERE id = ?', [1]);

      expect(mockMySQLPool.query).toHaveBeenCalledWith('SELECT * FROM User WHERE id = ?', [1]);
      expect(result.rows).toEqual([{ id: 1, name: 'test' }]);
      expect(result.rowCount).toBe(1);
      expect(result.fields).toEqual([{ name: 'id', type: 'int' }]);
    });

    it('should execute MySQL query without params', async () => {
      mockMySQLPool.query.mockResolvedValue([
        [{ id: 1, name: 'test' }],
        [],
      ]);

      const result = await service.query('SELECT * FROM User');

      expect(mockMySQLPool.query).toHaveBeenCalledWith('SELECT * FROM User', []);
      expect(result.rows).toEqual([{ id: 1, name: 'test' }]);
    });

    it('should execute PostgreSQL query', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const result = await postgresService.query('SELECT * FROM User');

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should execute SQLite query', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const result = await sqliteService.query('SELECT * FROM User');

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.query('SELECT * FROM User')).rejects.toThrow('不支持的数据库类型: unsupported');
    });

    it('should throw error when MySQL query fails', async () => {
      const error = new Error('Query failed');
      mockMySQLPool.query.mockRejectedValue(error);

      await expect(service.query('SELECT * FROM User')).rejects.toThrow('Query failed');
    });

    it('should handle empty result set', async () => {
      mockMySQLPool.query.mockResolvedValue([[], []]);

      const result = await service.query('SELECT * FROM User WHERE id = ?', [999]);

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });
  });

  describe('getTableSchema - Table Schema Retrieval', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should get MySQL table schema successfully', async () => {
      // Mock column query result
      const columnsResult = [
        {
          columnName: 'id',
          dataType: 'int',
          columnType: 'int(11)',
          isNullable: 'NO',
          columnKey: 'PRI',
          columnDefault: null,
          extra: 'auto_increment',
          columnComment: 'Primary key',
        },
        {
          columnName: 'name',
          dataType: 'varchar',
          columnType: 'varchar(255)',
          isNullable: 'YES',
          columnKey: '',
          columnDefault: null,
          extra: '',
          columnComment: 'User name',
        },
      ];

      // Mock index query result
      const indexesResult = [
        { indexName: 'PRIMARY', columnName: 'id', nonUnique: 0, seqInIndex: 1 },
        { indexName: 'idx_name', columnName: 'name', nonUnique: 1, seqInIndex: 1 },
      ];

      // Mock foreign key query result
      const foreignKeysResult = [
        {
          constraintName: 'fk_user_role',
          columnName: 'roleId',
          referencedTable: 'Role',
          referencedColumn: 'id',
        },
      ];

      // Mock table comment query result
      const tableCommentResult = [{ comment: 'User table' }];

      mockMySQLPool.query
        .mockResolvedValueOnce([columnsResult, []])
        .mockResolvedValueOnce([indexesResult, []])
        .mockResolvedValueOnce([foreignKeysResult, []])
        .mockResolvedValueOnce([tableCommentResult, []]);

      const schema = await service.getTableSchema('User');

      expect(schema.tableName).toBe('User');
      expect(schema.comment).toBe('User table');
      expect(schema.columns).toHaveLength(2);
      expect(schema.columns[0]).toEqual({
        name: 'id',
        type: 'int',
        fullType: 'int(11)',
        nullable: false,
        primaryKey: true,
        autoIncrement: true,
        default: null,
        comment: 'Primary key',
      });
      expect(schema.columns[1]).toEqual({
        name: 'name',
        type: 'varchar',
        fullType: 'varchar(255)',
        nullable: true,
        primaryKey: false,
        autoIncrement: false,
        default: null,
        comment: 'User name',
      });
      expect(schema.indexes).toHaveLength(2);
      expect(schema.indexes[0]).toEqual({
        name: 'PRIMARY',
        columns: [{ columnName: 'id', nonUnique: false, seqInIndex: 1 }],
        unique: true,
        primary: true,
      });
      expect(schema.foreignKeys).toHaveLength(1);
      expect(schema.foreignKeys[0]).toEqual({
        constraintName: 'fk_user_role',
        columnName: 'roleId',
        referencedTable: 'Role',
        referencedColumn: 'id',
      });
    });

    it('should get PostgreSQL table schema', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const schema = await postgresService.getTableSchema('User');

      expect(schema.tableName).toBe('User');
      expect(schema.columns).toEqual([]);
      expect(schema.constraints).toEqual([]);
      expect(schema.indexes).toEqual([]);
    });

    it('should get SQLite table schema', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const schema = await sqliteService.getTableSchema('User');

      expect(schema.tableName).toBe('User');
      expect(schema.columns).toEqual([]);
      expect(schema.indexes).toEqual([]);
    });

    it('should throw error when MySQL pool not initialized', async () => {
      const error = new Error('MySQL连接池未初始化');
      mockMySQLPool.query.mockRejectedValue(error);

      await expect(service.getTableSchema('User')).rejects.toThrow('MySQL连接池未初始化');
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.getTableSchema('User')).rejects.toThrow('不支持的数据库类型: unsupported');
    });
  });

  describe('getTables - Get All Tables', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should get MySQL tables successfully', async () => {
      const tablesResult = [
        { tableName: 'User' },
        { tableName: 'Moment' },
        { tableName: 'Comment' },
      ];

      mockMySQLPool.query.mockResolvedValueOnce([tablesResult, []]);

      const tables = await service.getTables();

      expect(tables).toEqual(['User', 'Moment', 'Comment']);
      expect(mockMySQLPool.query).toHaveBeenCalledWith(
        expect.stringContaining('SELECT TABLE_NAME as tableName FROM information_schema.TABLES'),
        []
      );
    });

    it('should get PostgreSQL tables', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const tables = await postgresService.getTables();

      expect(tables).toEqual([]);
    });

    it('should get SQLite tables', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const tables = await sqliteService.getTables();

      expect(tables).toEqual([]);
    });

    it('should throw error when MySQL pool not initialized', async () => {
      const error = new Error('MySQL连接池未初始化');
      mockMySQLPool.query.mockRejectedValue(error);

      await expect(service.getTables()).rejects.toThrow('MySQL连接池未初始化');
    });

    it('should handle empty table list', async () => {
      mockMySQLPool.query.mockResolvedValueOnce([[], []]);

      const tables = await service.getTables();

      expect(tables).toEqual([]);
    });
  });

  describe('testConnection - Connection Testing', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should test MySQL connection successfully', async () => {
      const mockConnection = {
        ping: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const result = await service.testConnection();

      expect(result).toBe(true);
      expect(mockMySQLPool.getConnection).toHaveBeenCalled();
      expect(mockConnection.ping).toHaveBeenCalled();
      expect(mockConnection.release).toHaveBeenCalled();
    });

    it('should test PostgreSQL connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const result = await postgresService.testConnection();

      expect(result).toBe(true);
    });

    it('should test SQLite connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const result = await sqliteService.testConnection();

      expect(result).toBe(true);
    });

    it('should return false when MySQL connection test fails', async () => {
      const mockConnection = {
        ping: vi.fn().mockRejectedValue(new Error('Connection failed')),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const result = await service.testConnection();

      expect(result).toBe(false);
    });

    it('should throw error when MySQL pool not initialized', async () => {
      const error = new Error('MySQL连接池未初始化');
      mockMySQLPool.getConnection.mockRejectedValue(error);

      await expect(service.testConnection()).rejects.toThrow('MySQL连接池未初始化');
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.testConnection()).rejects.toThrow('不支持的数据库类型: unsupported');
    });
  });

  describe('getDatabaseVersion - Database Version', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should get MySQL version successfully', async () => {
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ version: '8.0.33' }],
        [],
      ]);

      const version = await service.getDatabaseVersion();

      expect(version).toBe('8.0.33');
      expect(mockMySQLPool.query).toHaveBeenCalledWith('SELECT VERSION() as version', []);
    });

    it('should return unknown when MySQL version query fails', async () => {
      mockMySQLPool.query.mockRejectedValue(new Error('Query failed'));

      const version = await service.getDatabaseVersion();

      expect(version).toBe('unknown');
    });

    it('should return PostgreSQL version (mock)', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const version = await postgresService.getDatabaseVersion();

      expect(version).toBe('PostgreSQL (模拟)');
    });

    it('should return SQLite version (mock)', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const version = await sqliteService.getDatabaseVersion();

      expect(version).toBe('SQLite (模拟)');
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.getDatabaseVersion()).rejects.toThrow('不支持的数据库类型: unsupported');
    });
  });

  describe('getDatabaseSize - Database Size', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should get MySQL database size successfully', async () => {
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ database: 'test', size: 10.5 }],
        [],
      ]);

      const size = await service.getDatabaseSize();

      expect(size.database).toBe('test');
      expect(size.size).toBe(10.5);
      expect(size.unit).toBe('MB');
      expect(mockMySQLPool.query).toHaveBeenCalledWith(
        expect.stringContaining('SELECT table_schema AS database'),
        []
      );
    });

    it('should return default size when MySQL query fails', async () => {
      mockMySQLPool.query.mockRejectedValue(new Error('Query failed'));

      const size = await service.getDatabaseSize();

      expect(size.database).toBe('test');
      expect(size.size).toBe(0);
      expect(size.unit).toBe('MB');
    });

    it('should return PostgreSQL size (mock)', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      const size = await postgresService.getDatabaseSize();

      expect(size.database).toBe('test');
      expect(size.size).toBe(0);
      expect(size.unit).toBe('MB');
    });

    it('should return SQLite size (mock)', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      const size = await sqliteService.getDatabaseSize();

      expect(size.database).toBe('./test.db');
      expect(size.size).toBe(0);
      expect(size.unit).toBe('MB');
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.getDatabaseSize()).rejects.toThrow('不支持的数据库类型: unsupported');
    });
  });

  describe('executeTransaction - Transaction Execution', () => {
    beforeEach(async () => {
      await service['onModuleInit']();
    });

    it('should execute MySQL transaction successfully', async () => {
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ id: 1 }], []])
          .mockResolvedValueOnce([[{ id: 2 }], []])
          .mockResolvedValueOnce([[{ id: 3 }], []]),
        commit: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const queries = [
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Alice'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Bob'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Charlie'] },
      ];

      const results = await service.executeTransaction(queries);

      expect(mockConnection.beginTransaction).toHaveBeenCalled();
      expect(mockConnection.query).toHaveBeenCalledTimes(3);
      expect(mockConnection.query).toHaveBeenNthCalledWith(1, 'INSERT INTO User (name) VALUES (?)', ['Alice']);
      expect(mockConnection.query).toHaveBeenNthCalledWith(2, 'INSERT INTO User (name) VALUES (?)', ['Bob']);
      expect(mockConnection.query).toHaveBeenNthCalledWith(3, 'INSERT INTO User (name) VALUES (?)', ['Charlie']);
      expect(mockConnection.commit).toHaveBeenCalled();
      expect(mockConnection.release).toHaveBeenCalled();
      expect(results).toHaveLength(3);
    });

    it('should rollback transaction on error', async () => {
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ id: 1 }], []])
          .mockRejectedValueOnce(new Error('Insert failed')),
        rollback: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const queries = [
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Alice'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Bob'] },
      ];

      await expect(service.executeTransaction(queries)).rejects.toThrow('Insert failed');
      expect(mockConnection.rollback).toHaveBeenCalled();
      expect(mockConnection.release).toHaveBeenCalled();
    });

    it('should throw error for non-MySQL database', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      await expect(postgresService.executeTransaction([{ sql: 'SELECT 1' }])).rejects.toThrow('事务功能仅支持MySQL');
    });

    it('should handle empty query list', async () => {
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        commit: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const results = await service.executeTransaction([]);

      expect(results).toEqual([]);
      expect(mockConnection.beginTransaction).toHaveBeenCalled();
      expect(mockConnection.commit).toHaveBeenCalled();
    });

    it('should handle queries without params', async () => {
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ id: 1 }], []]),
        commit: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const queries = [
        { sql: 'SELECT 1' },
      ];

      const results = await service.executeTransaction(queries);

      expect(results).toHaveLength(1);
      expect(mockConnection.query).toHaveBeenCalledWith('SELECT 1', []);
    });
  });

  describe('close - Connection Cleanup', () => {
    it('should close MySQL connection successfully', async () => {
      await service['onModuleInit']();

      await service.close();

      expect(mockMySQLPool.end).toHaveBeenCalled();
      expect(service['connection']).toBeNull();
    });

    it('should close PostgreSQL connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'postgres',
        database: 'test',
      });

      const postgresService = new DatabaseService(mockConfigService as any);
      await postgresService['onModuleInit']();

      await postgresService.close();

      expect(postgresService['connection']).toBeNull();
    });

    it('should close SQLite connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'sqlite',
        database: './test.db',
      });

      const sqliteService = new DatabaseService(mockConfigService as any);
      await sqliteService['onModuleInit']();

      await sqliteService.close();

      expect(sqliteService['connection']).toBeNull();
    });

    it('should throw error for unsupported database type', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'unsupported',
        database: 'test',
      });

      const unsupportedService = new DatabaseService(mockConfigService as any);
      await unsupportedService['onModuleInit']();

      await expect(unsupportedService.close()).rejects.toThrow('不支持的数据库类型: unsupported');
    });

    it('should handle error when closing MySQL connection', async () => {
      await service['onModuleInit']();

      const error = new Error('Close failed');
      mockMySQLPool.end.mockRejectedValue(error);

      await expect(service.close()).rejects.toThrow('Close failed');
    });

    it('should handle closing already closed connection', async () => {
      mockConfigService.get.mockReturnValue({
        type: 'mysql',
        database: 'test',
      });

      const mysqlService = new DatabaseService(mockConfigService as any);
      await mysqlService['onModuleInit']();
      await mysqlService.close();

      // Close again
      await mysqlService.close();

      expect(mysqlService['connection']).toBeNull();
    });
  });

  describe('Edge Cases', () => {
    it('should handle null query result', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce([null, []]);

      const result = await service.query('SELECT * FROM User WHERE id = ?', [999]);

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should handle undefined query result', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce([undefined, []]);

      const result = await service.query('SELECT * FROM User WHERE id = ?', [999]);

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should handle non-array query result', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce(['not-an-array', []]);

      const result = await service.query('SELECT * FROM User');

      expect(result.rows).toEqual([]);
      expect(result.rowCount).toBe(0);
    });

    it('should handle empty params array', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce([[{ id: 1 }], []]);

      const result = await service.query('SELECT * FROM User', []);

      expect(mockMySQLPool.query).toHaveBeenCalledWith('SELECT * FROM User', []);
      expect(result.rows).toEqual([{ id: 1 }]);
    });

    it('should handle null params', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce([[{ id: 1 }], []]);

      const result = await service.query('SELECT * FROM User', null as any);

      expect(mockMySQLPool.query).toHaveBeenCalledWith('SELECT * FROM User', null);
      expect(result.rows).toEqual([{ id: 1 }]);
    });

    it('should handle special characters in table name', async () => {
      await service['onModuleInit']();

      const columnsResult = [
        {
          columnName: 'id',
          dataType: 'int',
          columnType: 'int(11)',
          isNullable: 'NO',
          columnKey: 'PRI',
          columnDefault: null,
          extra: 'auto_increment',
          columnComment: '',
        },
      ];

      mockMySQLPool.query.mockResolvedValueOnce([columnsResult, []]);

      const schema = await service.getTableSchema('User_Table');

      expect(schema.tableName).toBe('User_Table');
      expect(schema.columns).toHaveLength(1);
    });

    it('should handle large result sets', async () => {
      await service['onModuleInit']();

      const largeResult = Array.from({ length: 10000 }, (_, i) => ({ id: i + 1, name: `User${i + 1}` }));

      mockMySQLPool.query.mockResolvedValueOnce([largeResult, []]);

      const result = await service.query('SELECT * FROM User');

      expect(result.rows).toHaveLength(10000);
      expect(result.rowCount).toBe(10000);
    });

    it('should handle concurrent queries', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValue([
        [{ id: 1, name: 'test' }],
        [],
      ]);

      const queries = [
        service.query('SELECT * FROM User WHERE id = ?', [1]),
        service.query('SELECT * FROM User WHERE id = ?', [2]),
        service.query('SELECT * FROM User WHERE id = ?', [3]),
      ];

      const results = await Promise.all(queries);

      expect(results).toHaveLength(3);
      expect(mockMySQLPool.query).toHaveBeenCalledTimes(3);
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle multiple database operations', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query
        .mockResolvedValueOnce([[{ id: 1, name: 'Alice' }], []])
        .mockResolvedValueOnce([[{ id: 2, name: 'Bob' }], []])
        .mockResolvedValueOnce([[{ id: 3, name: 'Charlie' }], []]);

      const result1 = await service.query('SELECT * FROM User WHERE id = ?', [1]);
      const result2 = await service.query('SELECT * FROM User WHERE id = ?', [2]);
      const result3 = await service.query('SELECT * FROM User WHERE id = ?', [3]);

      expect(result1.rows[0].name).toBe('Alice');
      expect(result2.rows[0].name).toBe('Bob');
      expect(result3.rows[0].name).toBe('Charlie');
    });

    it('should handle transaction with multiple operations', async () => {
      await service['onModuleInit']();

      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ id: 1 }], []])
          .mockResolvedValueOnce([[{ id: 2 }], []])
          .mockResolvedValueOnce([[{ id: 3 }], []])
          .mockResolvedValueOnce([[{ id: 4 }], []]),
        commit: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const queries = [
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Alice'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Bob'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['Charlie'] },
        { sql: 'INSERT INTO User (name) VALUES (?)', params: ['David'] },
      ];

      const results = await service.executeTransaction(queries);

      expect(results).toHaveLength(4);
      expect(mockConnection.query).toHaveBeenCalledTimes(4);
    });

    it('should handle getting schema for non-existent table', async () => {
      await service['onModuleInit']();

      mockMySQLPool.query.mockResolvedValueOnce([[], []]);

      const schema = await service.getTableSchema('NonExistentTable');

      expect(schema.tableName).toBe('NonExistentTable');
      expect(schema.columns).toEqual([]);
      expect(schema.indexes).toEqual([]);
      expect(schema.foreignKeys).toEqual([]);
    });
  });
});
