import { describe, it, expect, beforeEach } from 'vitest';
import { MySQLBuilderService } from './mysql-builder.service';
import { ParseResult, BuildResult, Query } from '@/interfaces/apijson-request.interface';

describe('MySQLBuilderService', () => {
  let service: MySQLBuilderService;

  beforeEach(() => {
    service = new MySQLBuilderService();
  });

  describe('build - SELECT Operations', () => {
    it('should build simple SELECT query', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name', 'age'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result).toBeDefined();
      expect(result.queries).toBeDefined();
      expect(result.queries).toHaveLength(1);
      expect(result.queries[0].table).toBe('User');
      expect(result.queries[0].type).toBe('SELECT');
      expect(result.queries[0].sql).toContain('SELECT id, name, age FROM User');
      expect(result.queries[0].sql).toContain('WHERE id = 1');
      expect(result.queries[0].sql).toContain('LIMIT 10');
    });

    it('should build SELECT with * columns', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT * FROM User');
    });

    it('should build SELECT with column aliases', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: 'id,name:userName,age:userAge',
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT id, name AS userName, age AS userAge FROM User');
    });
  });

  describe('build - INSERT Operations', () => {
    it('should build INSERT query', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'POST',
            columns: ['*'],
            where: {},
            data: { name: '张三', age: 25 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].type).toBe('INSERT');
      expect(result.queries[0].sql).toContain('INSERT INTO User');
      expect(result.queries[0].sql).toContain('(name, age)');
      expect(result.queries[0].sql).toContain('VALUES');
    });

    it('should build INSERT with specific columns', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'POST',
            columns: ['name', 'age', 'email'],
            where: {},
            data: { name: '张三', age: 25, email: 'test@example.com' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('INSERT INTO User (name, age, email)');
    });

    it('should build INSERT with NULL values', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'POST',
            columns: ['*'],
            where: {},
            data: { name: '张三', age: null, email: null },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('VALUES (\'张三\', NULL, NULL)');
    });
  });

  describe('build - UPDATE Operations', () => {
    it('should build UPDATE query', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'PUT',
            columns: ['*'],
            where: { id: 1 },
            data: { name: '李四', age: 30 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].type).toBe('UPDATE');
      expect(result.queries[0].sql).toContain('UPDATE User');
      expect(result.queries[0].sql).toContain('SET name = \'李四\', age = 30');
      expect(result.queries[0].sql).toContain('WHERE id = 1');
    });

    it('should build UPDATE with partial data', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'PUT',
            columns: ['name', 'age'],
            where: { id: 1 },
            data: { name: '李四' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('UPDATE User SET name = \'李四\' WHERE id = 1');
    });
  });

  describe('build - DELETE Operations', () => {
    it('should build DELETE query', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'DELETE',
            columns: ['*'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].type).toBe('DELETE');
      expect(result.queries[0].sql).toContain('DELETE FROM User');
      expect(result.queries[0].sql).toContain('WHERE id = 1');
    });

    it('should build DELETE with multiple conditions', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'DELETE',
            columns: ['*'],
            where: { id: 1, 'age>': 18 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('DELETE FROM User WHERE id = 1 AND age > 18');
    });
  });

  describe('build - COUNT Operations', () => {
    it('should build COUNT query', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'HEAD',
            columns: ['COUNT(*)'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].type).toBe('COUNT');
      expect(result.queries[0].sql).toContain('SELECT COUNT(*) FROM User');
    });

    it('should build COUNT with alias', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'HEAD',
            columns: 'COUNT(*):total',
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT COUNT(*) AS total FROM User');
    });

    it('should build COUNT with WHERE', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'HEAD',
            columns: ['COUNT(*)'],
            where: { 'age>': 18 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT COUNT(*) FROM User WHERE age > 18');
    });
  });

  describe('build - Condition Operators', () => {
    it('should build equality condition (=)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id = 1');
    });

    it('should build not equal condition (!=)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'id!=': 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id != 1');
    });

    it('should build greater than condition (>)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age>': 18 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age > 18');
    });

    it('should build less than condition (<)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age<': 60 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age < 60');
    });

    it('should build greater than or equal condition (>=)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age>=': 18 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age >= 18');
    });

    it('should build less than or equal condition (<=)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age<=': 60 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age <= 60');
    });

    it('should build fuzzy match condition (~)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'name~': '张' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain("WHERE name LIKE '%张%'");
    });

    it('should build not fuzzy match condition (!~)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'name!~': '张' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain("WHERE name NOT LIKE '%张%'");
    });

    it('should build IN condition ({})', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'id{}': [1, 2, 3] },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id IN (1, 2, 3)');
    });

    it('should build NOT IN condition (!{})', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'id!{}': [1, 2, 3] },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id NOT IN (1, 2, 3)');
    });

    it('should build BETWEEN condition (><)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age><': [18, 60] },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age BETWEEN 18 AND 60');
    });

    it('should build NOT BETWEEN condition (!><)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'age!><': [18, 60] },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age NOT BETWEEN 18 AND 60');
    });

    it('should build array contains condition (<>)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'tagIds<>': 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('JSON_CONTAINS(tagIds, 1)');
    });

    it('should build array not contains condition (!<>)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'tagIds!<>': 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('NOT JSON_CONTAINS(tagIds, 1)');
    });
  });

  describe('build - JOIN Operations', () => {
    it('should build APP JOIN (@)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '@', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('INNER JOIN Moment ON User.id = Moment.userId');
    });

    it('should build INNER JOIN (&)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '&', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('INNER JOIN Moment ON User.id = Moment.userId');
    });

    it('should build LEFT JOIN (<)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '<', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LEFT JOIN Moment ON User.id = Moment.userId');
    });

    it('should build RIGHT JOIN (>)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '>', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('RIGHT JOIN Moment ON User.id = Moment.userId');
    });

    it('should build FULL JOIN (|)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '|', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('FULL JOIN Moment ON User.id = Moment.userId');
    });

    it('should build OUTER JOIN (!)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '!', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LEFT OUTER JOIN Moment ON User.id = Moment.userId');
    });

    it('should build SIDE JOIN (^)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '^', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LEFT JOIN Moment ON User.id = Moment.userId');
    });

    it('should build ANTI JOIN (()', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '(', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LEFT JOIN Moment ON User.id = Moment.userId');
    });

    it('should build FOREIGN JOIN ())', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: ')', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('INNER JOIN Moment ON User.id = Moment.userId');
    });

    it('should build ASOF JOIN (~)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '~', table: 'Moment', on: 'User.id = Moment.userId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LEFT JOIN Moment ON User.id = Moment.userId');
    });

    it('should build multiple JOINs', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [
              { type: '&', table: 'Moment', on: 'User.id = Moment.userId' },
              { type: '<', table: 'Comment', on: 'Moment.id = Comment.momentId' },
            ],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('INNER JOIN Moment ON User.id = Moment.userId');
      expect(result.queries[0].sql).toContain('LEFT JOIN Comment ON Moment.id = Comment.momentId');
    });
  });

  describe('build - GROUP BY and HAVING', () => {
    it('should build GROUP BY clause', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['department', 'COUNT(*) AS count'],
            where: {},
            joins: [],
            group: ['department'],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('GROUP BY department');
    });

    it('should build GROUP BY with multiple columns', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['department', 'role', 'COUNT(*) AS count'],
            where: {},
            joins: [],
            group: ['department', 'role'],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('GROUP BY department, role');
    });

    it('should build HAVING clause', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['department', 'COUNT(*) AS count'],
            where: {},
            joins: [],
            group: ['department'],
            having: { 'COUNT(*)>': 5 },
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('HAVING COUNT(*) > 5');
    });

    it('should build GROUP BY and HAVING together', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['department', 'COUNT(*) AS count'],
            where: {},
            joins: [],
            group: ['department'],
            having: { 'COUNT(*)>': 5 },
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      const sql = result.queries[0].sql;
      expect(sql).toContain('GROUP BY department');
      expect(sql).toContain('HAVING COUNT(*) > 5');
    });
  });

  describe('build - ORDER BY', () => {
    it('should build ORDER BY ASC', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: ['name+'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('ORDER BY name ASC');
    });

    it('should build ORDER BY DESC', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: ['name-'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('ORDER BY name DESC');
    });

    it('should build ORDER BY with multiple columns', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: ['name+', 'age-'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('ORDER BY name ASC, age DESC');
    });
  });

  describe('build - LIMIT and OFFSET', () => {
    it('should build LIMIT clause', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 50,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LIMIT 50');
    });

    it('should build OFFSET clause', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 100,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('OFFSET 100');
    });

    it('should build LIMIT and OFFSET together', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 20,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      const sql = result.queries[0].sql;
      expect(sql).toContain('LIMIT 10');
      expect(sql).toContain('OFFSET 20');
    });
  });

  describe('build - Value Formatting', () => {
    it('should format NULL value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { deletedAt: null },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE deletedAt IS NULL');
    });

    it('should format string value with quotes', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { name: 'John' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain("WHERE name = 'John'");
    });

    it('should format string value with single quote', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { name: "O'Brien" },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain("WHERE name = 'O''Brien'");
    });

    it('should format number value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { age: 25 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE age = 25');
    });

    it('should format boolean true value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { isActive: true },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE isActive = TRUE');
    });

    it('should format boolean false value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { isActive: false },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE isActive = FALSE');
    });

    it('should format array value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { 'id{}': [1, 2, 3] },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id IN (1, 2, 3)');
    });

    it('should format object value', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { metadata: JSON.stringify({ key: 'value' }) },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain("WHERE metadata = '{\"key\":\"value\"}'");
    });
  });

  describe('build - Aggregate Functions', () => {
    it('should build COUNT function', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['COUNT(*) AS count'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('COUNT(*) AS count');
    });

    it('should build SUM function', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['SUM(age) AS totalAge'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SUM(age) AS totalAge');
    });

    it('should build AVG function', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['AVG(age) AS avgAge'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('AVG(age) AS avgAge');
    });

    it('should build MIN function', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['MIN(age) AS minAge'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('MIN(age) AS minAge');
    });

    it('should build MAX function', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['MAX(age) AS maxAge'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('MAX(age) AS maxAge');
    });

    it('should build multiple aggregate functions', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['COUNT(*) AS count', 'SUM(age) AS totalAge', 'AVG(age) AS avgAge'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      const sql = result.queries[0].sql;
      expect(sql).toContain('COUNT(*) AS count');
      expect(sql).toContain('SUM(age) AS totalAge');
      expect(sql).toContain('AVG(age) AS avgAge');
    });
  });

  describe('build - Reference Assignment', () => {
    it('should handle reference assignment in WHERE', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
          Moment: {
            name: 'Moment',
            operation: 'GET',
            columns: ['*'],
            where: { 'userId@': '/User/id' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[1].sql).toContain('WHERE userId = ?');
      expect(result.queries[1].params).toBeDefined();
    });

    it('should handle array reference assignment', async () => {
      const parseResult: ParseResult = {
        tables: {
          'User[]': {
            name: 'User',
            operation: 'GETS',
            columns: ['*'],
            where: { 'age>': 18 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
            isArray: true,
          },
          Moment: {
            name: 'Moment',
            operation: 'GET',
            columns: ['*'],
            where: { 'userId{}@': '[]/User/id' },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[1].sql).toContain('WHERE userId IN (?)');
    });
  });

  describe('build - Complex Queries', () => {
    it('should build query with all clauses', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name', 'age'],
            where: { status: 'active', 'age>': 18 },
            joins: [
              { type: '&', table: 'Profile', on: 'User.id = Profile.userId' },
            ],
            group: ['department'],
            having: { 'COUNT(*)>': 5 },
            order: ['name+', 'age-'],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      const sql = result.queries[0].sql;
      expect(sql).toContain('SELECT id, name, age FROM User');
      expect(sql).toContain('INNER JOIN Profile ON User.id = Profile.userId');
      expect(sql).toContain("WHERE status = 'active' AND age > 18");
      expect(sql).toContain('GROUP BY department');
      expect(sql).toContain('HAVING COUNT(*) > 5');
      expect(sql).toContain('ORDER BY name ASC, age DESC');
      expect(sql).toContain('LIMIT 10');
    });

    it('should build multiple table queries', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { id: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
          Moment: {
            name: 'Moment',
            operation: 'GET',
            columns: ['id', 'content'],
            where: { userId: 1 },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 20,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries).toHaveLength(2);
      expect(result.queries[0].table).toBe('User');
      expect(result.queries[1].table).toBe('Moment');
    });

    it('should build query with subquery', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['id', 'name'],
            where: { 'id{}': { table: 'Moment', column: 'userId', condition: 'userId = 1' } },
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('WHERE id IN (SELECT userId FROM Moment WHERE userId = 1)');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty columns (default to *)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: [],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT * FROM User');
    });

    it('should handle null columns (default to *)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: null as any,
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT * FROM User');
    });

    it('should handle empty where (no WHERE clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('WHERE');
    });

    it('should handle empty joins (no JOIN clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('JOIN');
    });

    it('should handle empty group (no GROUP BY clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('GROUP BY');
    });

    it('should handle empty having (no HAVING clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('HAVING');
    });

    it('should handle empty order (no ORDER BY clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('ORDER BY');
    });

    it('should handle zero limit (no LIMIT clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 0,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('LIMIT');
    });

    it('should handle zero offset (no OFFSET clause)', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).not.toContain('OFFSET');
    });

    it('should handle very long column list', async () => {
      const columns = Array.from({ length: 100 }, (_, i) => `column${i}`);
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns,
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('SELECT ' + columns.join(', ') + ' FROM User');
    });

    it('should handle very large limit', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 999999,
            offset: 0,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('LIMIT 999999');
    });

    it('should handle very large offset', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 999999,
          },
        },
        directives: {},
        original: {},
      };

      const result = await service.build(parseResult);

      expect(result.queries[0].sql).toContain('OFFSET 999999');
    });

    it('should preserve original parse result', async () => {
      const parseResult: ParseResult = {
        tables: {
          User: {
            name: 'User',
            operation: 'GET',
            columns: ['*'],
            where: {},
            joins: [],
            group: [],
            having: {},
            order: [],
            limit: 10,
            offset: 0,
          },
        },
        directives: {},
        original: { test: 'value' },
      };

      const result = await service.build(parseResult);

      expect(result.original).toEqual(parseResult);
    });
  });
});
