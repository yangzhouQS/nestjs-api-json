import {Test, TestingModule} from '@nestjs/testing';
import {INestApplication, ValidationPipe} from '@nestjs/common';
import * as request from 'supertest';
import {AppModule} from '../../src/app.module';
import {beforeAll, describe, it} from 'vitest';

/**
 * APIJSON E2E 增强测试
 * 测试完整的请求-响应周期，包括认证、授权、错误处理和性能
 */
describe('APIJSON E2E Enhanced Tests', () => {
    let app: INestApplication;

    beforeAll(async () => {
        const moduleFixture: TestingModule = await Test.createTestingModule({
            imports: [AppModule],
        }).compile();

        app = moduleFixture.createNestApplication();
        app.useGlobalPipes(new ValidationPipe());
        await app.init();
    });

    afterAll(async () => {
        await app.close();
    });

    describe('Authentication and Authorization', () => {
        describe('POST /auth/login', () => {
            it('should login with valid credentials', async () => {
                const response = await request(app.getHttpServer())
                    .post('/auth/login')
                    .send({
                        phone: '13000038710',
                        password: 'apijson',
                    })
                    .expect(200);

                expect(response.body).toHaveProperty('code', 200);
                expect(response.body).toHaveProperty('data');
                expect(response.body.data).toHaveProperty('token');
                expect(response.body.data).toHaveProperty('userId');
            });

            it('should reject login with invalid credentials', async () => {
                const response = await request(app.getHttpServer())
                    .post('/auth/login')
                    .send({
                        phone: '13000038710',
                        password: 'wrongpassword',
                    })
                    .expect(401);

                expect(response.body).toHaveProperty('code', 401);
                expect(response.body).toHaveProperty('msg');
            });

            it('should reject login with missing credentials', async () => {
                const response = await request(app.getHttpServer())
                    .post('/auth/login')
                    .send({
                        phone: '13000038710',
                    })
                    .expect(400);

                expect(response.body).toHaveProperty('code', 400);
            });
        });

        describe('Request with Authorization', () => {
            it('should access protected endpoint with valid token', async () => {
                // First login to get token
                const loginResponse = await request(app.getHttpServer())
                    .post('/auth/login')
                    .send({
                        phone: '13000038710',
                        password: 'apijson',
                    });

                const token = loginResponse.body.data.token;

                // Access protected endpoint
                const response = await request(app.getHttpServer())
                    .post('/apijson/get')
                    .set('Authorization', `Bearer ${token}`)
                    .send({
                        User: {
                            id: 1,
                        },
                    })
                    .expect(200);

                expect(response.body).toHaveProperty('code', 200);
            });

            it('should reject protected endpoint without token', async () => {
                const response = await request(app.getHttpServer())
                    .post('/apijson/post')
                    .send({
                        User: {
                            name: 'Test User',
                        },
                    })
                    .expect(401);

                expect(response.body).toHaveProperty('code', 401);
            });

            it('should reject protected endpoint with invalid token', async () => {
                const response = await request(app.getHttpServer())
                    .post('/apijson/post')
                    .set('Authorization', 'Bearer invalid-token')
                    .send({
                        User: {
                            name: 'Test User',
                        },
                    })
                    .expect(401);

                expect(response.body).toHaveProperty('code', 401);
            });
        });
    });

    describe('Complete Request-Response Cycle', () => {
        it('should handle complete CRUD cycle', async () => {
            // Create
            const createResponse = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'E2E Test User',
                        age: 25,
                    },
                })
                .expect(201);

            expect(createResponse.body.code).toBe(201);
            expect(createResponse.body.data.User).toHaveProperty('id');
            const userId = createResponse.body.data.User.id;

            // Read
            const readResponse = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: userId,
                    },
                })
                .expect(200);

            expect(readResponse.body.code).toBe(200);
            expect(readResponse.body.data.User.name).toBe('E2E Test User');

            // Update
            const updateResponse = await request(app.getHttpServer())
                .post('/apijson/put')
                .send({
                    User: {
                        id: userId,
                        name: 'Updated E2E Test User',
                    },
                })
                .expect(200);

            expect(updateResponse.body.code).toBe(200);

            // Delete
            const deleteResponse = await request(app.getHttpServer())
                .post('/apijson/delete')
                .send({
                    User: {
                        id: userId,
                    },
                })
                .expect(200);

            expect(deleteResponse.body.code).toBe(200);
        });

        it('should handle multi-table query cycle', async () => {
            // Create User
            const userResponse = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'E2E Multi-Table User',
                        age: 25,
                    },
                })
                .expect(201);

            const userId = userResponse.body.data.User.id;

            // Create Moment
            const momentResponse = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    Moment: {
                        userId: userId,
                        content: 'E2E Test Moment',
                    },
                })
                .expect(201);

            const momentId = momentResponse.body.data.Moment.id;

            // Create Comment
            const commentResponse = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    Comment: {
                        momentId: momentId,
                        content: 'E2E Test Comment',
                    },
                })
                .expect(201);

            // Query with JOIN
            const queryResponse = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    Moment: {
                        id: momentId,
                    },
                    join: '&/User/id@',
                })
                .expect(200);

            expect(queryResponse.body.code).toBe(200);
            expect(queryResponse.body.data).toHaveProperty('Moment');
            expect(queryResponse.body.data).toHaveProperty('User');
        });
    });

    describe('Error Handling', () => {
        it('should handle invalid JSON format', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .set('Content-Type', 'application/json')
                .send('invalid json')
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
            expect(response.body).toHaveProperty('msg');
        });

        it('should handle invalid request method', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/invalid-method')
                .send({
                    User: {
                        id: 1,
                    },
                })
                .expect(404);

            expect(response.body).toHaveProperty('code', 404);
        });

        it('should handle missing required fields', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {},
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle invalid data types', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'Test User',
                        age: 'not-a-number',
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle constraint violations', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'A'.repeat(1000), // Too long name
                        age: 25,
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle duplicate key violations', async () => {
            // First insert
            await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'Duplicate User',
                        age: 25,
                    },
                })
                .expect(201);

            // Second insert with same unique field
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'Duplicate User',
                        age: 30,
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle foreign key violations', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    Moment: {
                        userId: 99999, // Non-existent user
                        content: 'Test Moment',
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });
    });

    describe('Performance Testing', () => {
        it('should handle rapid sequential requests', async () => {
            const requests = Array.from({ length: 100 }, () => 
                request(app.getHttpServer())
                    .post('/apijson/get')
                    .send({
                        User: {
                            id: 1,
                        },
                    })
            );

            const startTime = Date.now();
            const responses = await Promise.all(requests);
            const endTime = Date.now();

            responses.forEach(response => {
                expect(response.status).toBe(200);
            });

            const duration = endTime - startTime;
            expect(duration).toBeLessThan(5000); // Should complete within 5 seconds
        });

        it('should handle concurrent requests', async () => {
            const requests = Array.from({ length: 50 }, (_, i) => 
                request(app.getHttpServer())
                    .post('/apijson/get')
                    .send({
                        User: {
                            id: (i % 10) + 1,
                        },
                    })
            );

            const startTime = Date.now();
            const responses = await Promise.all(requests);
            const endTime = Date.now();

            responses.forEach(response => {
                expect(response.status).toBe(200);
            });

            const duration = endTime - startTime;
            expect(duration).toBeLessThan(3000); // Should complete within 3 seconds
        });

        it('should handle large result sets efficiently', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/gets')
                .send({
                    'User[]': {
                        count: 1000,
                        User: {},
                    },
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(Array.isArray(response.body.data.User)).toBe(true);
            expect(response.body.data.User).toHaveLength(1000);
        });

        it('should handle complex queries efficiently', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    Moment: {
                        userId: 82001,
                    },
                    join: '&/User/id@,&/Comment/toId@',
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(response.body.data).toHaveProperty('Moment');
            expect(response.body.data).toHaveProperty('User');
            expect(response.body.data).toHaveProperty('Comment');
        });
    });

    describe('Security Testing', () => {
        it('should prevent SQL injection', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: "1; DROP TABLE User; --",
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
            // Should not actually drop the table
        });

        it('should prevent XSS attacks', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: '<script>alert("XSS")</script>',
                        age: 25,
                    },
                })
                .expect(201);

            expect(response.body.code).toBe(201);
            // The script should be escaped or sanitized in the response
        });

        it('should enforce rate limiting', async () => {
            const requests = Array.from({ length: 100 }, () => 
                request(app.getHttpServer())
                    .post('/apijson/get')
                    .send({
                        User: {
                            id: 1,
                        },
                    })
            );

            const responses = await Promise.all(requests);
            const successCount = responses.filter(r => r.status === 200).length;
            const rateLimitedCount = responses.filter(r => r.status === 429).length;

            // Some requests should be rate limited
            expect(rateLimitedCount).toBeGreaterThan(0);
        });

        it('should validate request size', async () => {
            const largeRequest = {
                'User[]': Array.from({ length: 10000 }, (_, i) => ({
                    name: `User${i}`,
                    age: 25,
                })),
            };

            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send(largeRequest)
                .expect(413); // Payload Too Large

            expect(response.body).toHaveProperty('code', 413);
        });

        it('should enforce permission checks', async () => {
            // Login as regular user
            const loginResponse = await request(app.getHttpServer())
                .post('/auth/login')
                .send({
                    phone: '13000038710',
                    password: 'apijson',
                });

            const token = loginResponse.body.data.token;

            // Try to access admin-only resource
            const response = await request(app.getHttpServer())
                .post('/admin/users')
                .set('Authorization', `Bearer ${token}`)
                .send({
                    User: {
                        id: 1,
                    },
                })
                .expect(403);

            expect(response.body).toHaveProperty('code', 403);
        });
    });

    describe('Data Consistency', () => {
        it('should maintain data integrity during concurrent operations', async () => {
            // Create initial user
            const createResponse = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'Concurrent Test User',
                        age: 25,
                    },
                })
                .expect(201);

            const userId = createResponse.body.data.User.id;

            // Concurrent updates
            const updateRequests = Array.from({ length: 10 }, (_, i) => 
                request(app.getHttpServer())
                    .post('/apijson/put')
                    .send({
                        User: {
                            id: userId,
                            age: 25 + i,
                        },
                    })
            );

            await Promise.all(updateRequests);

            // Verify final state
            const readResponse = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: userId,
                    },
                })
                .expect(200);

            expect(readResponse.body.code).toBe(200);
            expect(readResponse.body.data.User).toHaveProperty('age');
        });

        it('should handle transaction rollback on error', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/crud')
                .send({
                    User: {
                        '@method': 'POST',
                        name: 'Transaction Test User',
                        age: 25,
                    },
                    Moment: {
                        '@method': 'POST',
                        userId: 99999, // Invalid user
                        content: 'Test Moment',
                    },
                })
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
            // User should not be created due to transaction rollback
        });
    });

    describe('Response Format Validation', () => {
        it('should return consistent response format for success', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: 1,
                    },
                })
                .expect(200);

            expect(response.body).toHaveProperty('code');
            expect(response.body).toHaveProperty('msg');
            expect(response.body).toHaveProperty('data');
            expect(response.body.code).toBe(200);
            expect(response.body.msg).toBe('success');
        });

        it('should return consistent response format for error', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {},
                })
                .expect(400);

            expect(response.body).toHaveProperty('code');
            expect(response.body).toHaveProperty('msg');
            expect(response.body.code).not.toBe(200);
        });

        it('should include proper HTTP status codes', async () => {
            // Success
            const successResponse = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: 1,
                    },
                });

            expect(successResponse.status).toBe(200);

            // Client error
            const errorResponse = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {},
                });

            expect(errorResponse.status).toBeGreaterThanOrEqual(400);
            expect(errorResponse.status).toBeLessThan(500);
        });

        it('should include proper headers', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: 1,
                    },
                })
                .expect(200);

            expect(response.headers).toHaveProperty('content-type');
            expect(response.headers['content-type']).toMatch(/application\/json/);
        });
    });

    describe('Advanced Features E2E', () => {
        it('should handle complex multi-level JOIN queries', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    Moment: {
                        userId: 82001,
                        User: {
                            'id@': '/Moment/userId',
                            Comment: {
                                'momentId@': '/Moment/id',
                            },
                        },
                    },
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(response.body.data).toHaveProperty('Moment');
            expect(response.body.data.Moment).toHaveProperty('User');
        });

        it('should handle aggregation with GROUP BY', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/gets')
                .send({
                    User: {
                        '@column': 'department,COUNT(*):count',
                        '@group': 'department',
                    },
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(Array.isArray(response.body.data.User)).toBe(true);
        });

        it('should handle subqueries', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        'id{}': {
                            Moment: {
                                'userId@': '/User/id',
                            },
                        },
                    },
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(response.body.data).toHaveProperty('User');
        });

        it('should handle reference assignment', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({
                    User: {
                        id: 1,
                    },
                    Moment: {
                        'userId@': '/User/id',
                    },
                })
                .expect(200);

            expect(response.body.code).toBe(200);
            expect(response.body.data).toHaveProperty('User');
            expect(response.body.data).toHaveProperty('Moment');
        });
    });

    describe('Edge Cases E2E', () => {
        it('should handle empty request body', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/get')
                .send({})
                .expect(400);

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle null values', async () => {
            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: 'Test User',
                        age: null,
                    },
                })
                .expect(201);

            expect(response.body.code).toBe(201);
        });

        it('should handle very long strings', async () => {
            const longString = 'A'.repeat(10000);

            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: longString,
                        age: 25,
                    },
                })
                .expect(400); // Should fail due to length constraint

            expect(response.body).toHaveProperty('code', 400);
        });

        it('should handle special characters', async () => {
            const specialString = '测试🎉@#$%^&*()_+-={}[]|\\:";\'<>,.?/`~';

            const response = await request(app.getHttpServer())
                .post('/apijson/post')
                .send({
                    User: {
                        name: specialString,
                        age: 25,
                    },
                })
                .expect(201);

            expect(response.body.code).toBe(201);
        });
    });

    describe('Health and Monitoring', () => {
        it('should return health status', async () => {
            const response = await request(app.getHttpServer())
                .get('/health')
                .expect(200);

            expect(response.body).toHaveProperty('status', 'ok');
            expect(response.body).toHaveProperty('timestamp');
            expect(response.body).toHaveProperty('uptime');
        });

        it('should return service metrics', async () => {
            const response = await request(app.getHttpServer())
                .get('/metrics')
                .expect(200);

            expect(response.body).toHaveProperty('code', 200);
            expect(response.body).toHaveProperty('data');
            expect(response.body.data).toHaveProperty('requests');
            expect(response.body.data).toHaveProperty('errors');
            expect(response.body.data).toHaveProperty('latency');
        });
    });
});
