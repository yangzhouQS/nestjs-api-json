import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CoreParserService } from '../../src/modules/parser/core-parser.service';
import { MySQLBuilderService } from '../../src/modules/builder/mysql-builder.service';
import { MySQLExecutorService } from '../../src/modules/executor/mysql-executor.service';
import { VerifierService } from '../../src/modules/verifier/verifier.service';
import { DatabaseService } from '../../src/modules/database/database.service';
import { CacheService } from '../../src/modules/cache/cache.service';
import { ConfigService } from '@nestjs/config';

describe('APIJSON Integration Tests', () => {
  let parser: CoreParserService;
  let builder: MySQLBuilderService;
  let executor: MySQLExecutorService;
  let verifier: VerifierService;
  let database: DatabaseService;
  let cache: CacheService;
  let mockConfigService: any;
  let mockMySQLPool: any;

  beforeEach(async () => {
    // Mock ConfigService
    mockConfigService = {
      get: vi.fn().mockImplementation((key: string) => {
        const config = {
          'database.type': 'mysql',
          'database.host': 'localhost',
          'database.port': 3306,
          'database.user': 'root',
          'database.password': 'password',
          'database.database': 'test',
          'database.connectionLimit': 10,
          'cache.type': 'memory',
          'cache.keyPrefix': 'apijson:',
          'cache.defaultTTL': 60000,
          'cache.maxSize': 1000,
          'parser.maxQueryDepth': 5,
          'parser.maxObjectCount': 5,
          'parser.maxArrayCount': 5,
          'parser.maxQueryCount': 100,
          'parser.maxUpdateCount': 10,
        };
        return config[key];
      }),
    };

    // Mock MySQL Pool
    mockMySQLPool = {
      query: vi.fn(),
      getConnection: vi.fn(),
      end: vi.fn(),
    };

    // Mock mysql.createPool
    vi.mock('mysql2/promise', () => ({
      createPool: vi.fn().mockReturnValue(mockMySQLPool),
    }));

    // Create services
    cache = new CacheService(mockConfigService as any);
    database = new DatabaseService(mockConfigService as any);
    verifier = new VerifierService(mockConfigService as any);
    builder = new MySQLBuilderService(mockConfigService as any);
    executor = new MySQLExecutorService(mockConfigService as any, database, cache);
    parser = new CoreParserService(mockConfigService as any, verifier, builder, executor);

    // Initialize database
    await database['onModuleInit']();
  });

  afterEach(async () => {
    // Clear cache
    await cache.flush();

    // Close database
    await database.close();
  });

  describe('Complete Request Flow', () => {
    it('should execute GET request through parser → builder → executor', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ id: 1, name: 'Alice', age: 25 }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data.User).toEqual({ id: 1, name: 'Alice', age: 25 });
    });

    it('should execute GETS request through parser → builder → executor', async () => {
      const request = {
        'User[]': {
          count: 10,
          page: 0,
          User: {
            age>': 18,
          },
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { id: 1, name: 'Alice', age: 25 },
          { id: 2, name: 'Bob', age: 30 },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(Array.isArray(result.data.User)).toBe(true);
      expect(result.data.User).toHaveLength(2);
    });

    it('should execute POST request through parser → builder → executor', async () => {
      const request = {
        User: {
          name: 'Charlie',
          age: 28,
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ insertId: 3 }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data.User).toHaveProperty('id', 3);
    });

    it('should execute PUT request through parser → builder → executor', async () => {
      const request = {
        User: {
          id: 1,
          name: 'Updated Name',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ affectedRows: 1 }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data.User).toHaveProperty('id', 1);
    });

    it('should execute DELETE request through parser → builder → executor', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ affectedRows: 1 }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('count', 1);
    });
  });

  describe('Multi-table Query Integration', () => {
    it('should execute query with JOIN', async () => {
      const request = {
        Moment: {
          userId: 82001,
        },
        join: '&/User/id@',
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [
            { id: 1, userId: 82001, content: 'Test Moment' },
            { id: 82001, name: 'Test User' },
          ],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('Moment');
      expect(result.data).toHaveProperty('User');
    });

    it('should execute query with reference assignment', async () => {
      const request = {
        User: {
          id: 1,
        },
        Moment: {
          userId@': '/User/id',
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [{ id: 1, name: 'Alice' }],
          [],
        ])
        .mockResolvedValueOnce([
          [
            { id: 1, userId: 1, content: 'Test Moment' },
          ],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Moment');
    });

    it('should execute query with multiple tables', async () => {
      const request = {
        User: {
          id: 1,
        },
        Moment: {
          userId@': '/User/id',
        },
        Comment: {
          momentId@': '/Moment/id',
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [{ id: 1, name: 'Alice' }],
          [],
        ])
        .mockResolvedValueOnce([
          [{ id: 1, userId: 1, content: 'Test Moment' }],
          [],
        ])
        .mockResolvedValueOnce([
          [{ id: 1, momentId: 1, content: 'Test Comment' }],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Moment');
      expect(result.data).toHaveProperty('Comment');
    });

    it('should execute query with array reference', async () => {
      const request = {
        'User[]': {
          count: 5,
          User: {
            age>': 18,
          },
        },
        Moment: {
          userId{}@': '[]/User/id',
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [
            { id: 1, name: 'Alice' },
            { id: 2, name: 'Bob' },
          ],
          [],
        ])
        .mockResolvedValueOnce([
          [
            { id: 1, userId: 1, content: 'Moment 1' },
            { id: 2, userId: 2, content: 'Moment 2' },
          ],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Moment');
    });
  });

  describe('Complex Query Integration', () => {
    it('should execute query with GROUP BY and HAVING', async () => {
      const request = {
        User: {
          '@column': 'department,COUNT(*):count',
          '@group': 'department',
          '@having': 'count>5',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { department: 'IT', count: 10 },
          { department: 'HR', count: 6 },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(Array.isArray(result.data.User)).toBe(true);
    });

    it('should execute query with aggregate functions', async () => {
      const request = {
        User: {
          '@column': 'COUNT(*):total,SUM(age):totalAge,AVG(age):avgAge',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ total: 100, totalAge: 2500, avgAge: 25 }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data.User).toEqual({ total: 100, totalAge: 2500, avgAge: 25 });
    });

    it('should execute query with ORDER BY', async () => {
      const request = {
        'User[]': {
          count: 10,
          User: {
            '@order': 'age-,name+',
          },
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { id: 1, name: 'Alice', age: 30 },
          { id: 2, name: 'Bob', age: 25 },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(Array.isArray(result.data.User)).toBe(true);
    });

    it('should execute query with multiple WHERE conditions', async () => {
      const request = {
        User: {
          age>': 18,
          age<': 60,
          name~': 'A',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { id: 1, name: 'Alice', age: 25 },
          { id: 2, name: 'Anna', age: 30 },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(Array.isArray(result.data.User)).toBe(true);
    });

    it('should execute query with IN operator', async () => {
      const request = {
        User: {
          id{}': [1, 2, 3],
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { id: 1, name: 'Alice' },
          { id: 2, name: 'Bob' },
          { id: 3, name: 'Charlie' },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(Array.isArray(result.data.User)).toBe(true);
      expect(result.data.User).toHaveLength(3);
    });
  });

  describe('Transaction Integration', () => {
    it('should execute transaction with multiple operations', async () => {
      const request = {
        User: {
          '@method': 'POST',
          name: 'Alice',
          age: 25,
        },
        Moment: {
          '@method': 'POST',
          userId@': '/User/id',
          content: 'Test Moment',
        },
      };

      // Mock database queries
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ insertId: 1 }], []])
          .mockResolvedValueOnce([[{ insertId: 1 }], []]),
        commit: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(mockConnection.beginTransaction).toHaveBeenCalled();
      expect(mockConnection.commit).toHaveBeenCalled();
    });

    it('should rollback transaction on error', async () => {
      const request = {
        User: {
          '@method': 'POST',
          name: 'Alice',
          age: 25,
        },
        Moment: {
          '@method': 'POST',
          userId@': '/User/id',
          content: 'Test Moment',
        },
      };

      // Mock database queries with error
      const mockConnection = {
        beginTransaction: vi.fn().mockResolvedValue(undefined),
        query: vi.fn()
          .mockResolvedValueOnce([[{ insertId: 1 }], []])
          .mockRejectedValueOnce(new Error('Insert failed')),
        rollback: vi.fn().mockResolvedValue(undefined),
        release: vi.fn().mockResolvedValue(undefined),
      };

      mockMySQLPool.getConnection.mockResolvedValue(mockConnection);

      await expect(parser.parse(request)).rejects.toThrow('Insert failed');
      expect(mockConnection.rollback).toHaveBeenCalled();
    });
  });

  describe('Cache Integration', () => {
    it('should cache query results', async () => {
      const request = {
        User: {
          id: 1,
          '@cache': '60',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ id: 1, name: 'Alice', age: 25 }],
        [],
      ]);

      // First request
      const result1 = await parser.parse(request);
      expect(result1.code).toBe(200);
      expect(mockMySQLPool.query).toHaveBeenCalledTimes(1);

      // Second request should use cache
      const result2 = await parser.parse(request);
      expect(result2.code).toBe(200);
      expect(mockMySQLPool.query).toHaveBeenCalledTimes(1); // Should not increase
    });

    it('should invalidate cache on update', async () => {
      // Set cache
      await cache.set('User:1', { id: 1, name: 'Alice' });

      // Execute update
      const request = {
        User: {
          id: 1,
          name: 'Updated Name',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ affectedRows: 1 }],
        [],
      ]);

      const result = await parser.parse(request);
      expect(result.code).toBe(200);

      // Cache should be invalidated
      const cached = await cache.get('User:1');
      expect(cached).toBeNull();
    });

    it('should clear expired cache', async () => {
      // Set cache with short TTL
      await cache.set('testKey', 'testValue', 100);

      // Wait for cache to expire
      await new Promise(resolve => setTimeout(resolve, 150));

      const value = await cache.get('testKey');
      expect(value).toBeNull();
    });
  });

  describe('Verification Integration', () => {
    it('should verify and reject invalid request', async () => {
      const request = {
        User: {
          id: 'invalid-id',
        },
      };

      const result = await parser.parse(request);

      expect(result.code).not.toBe(200);
      expect(result).toHaveProperty('msg');
    });

    it('should verify and reject request without required fields', async () => {
      const request = {
        User: {},
      };

      const result = await parser.parse(request);

      expect(result.code).not.toBe(200);
    });

    it('should verify and accept valid request', async () => {
      const request = {
        User: {
          id: 1,
          name: 'Alice',
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [{ id: 1, name: 'Alice' }],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
    });
  });

  describe('Error Handling Integration', () => {
    it('should handle database connection error', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock database connection error
      mockMySQLPool.query.mockRejectedValue(new Error('Connection failed'));

      const result = await parser.parse(request);

      expect(result.code).not.toBe(200);
      expect(result).toHaveProperty('msg');
    });

    it('should handle SQL execution error', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock SQL execution error
      mockMySQLPool.query.mockRejectedValue(new Error('SQL syntax error'));

      const result = await parser.parse(request);

      expect(result.code).not.toBe(200);
      expect(result).toHaveProperty('msg');
    });

    it('should handle timeout error', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock timeout error
      mockMySQLPool.query.mockRejectedValue(new Error('Query timeout'));

      const result = await parser.parse(request);

      expect(result.code).not.toBe(200);
      expect(result).toHaveProperty('msg');
    });
  });

  describe('Performance Integration', () => {
    it('should handle rapid sequential requests', async () => {
      const request = {
        User: {
          id: 1,
        },
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValue([
        [{ id: 1, name: 'Alice' }],
        [],
      ]);

      const requests = Array.from({ length: 10 }, () => parser.parse(request));
      const results = await Promise.all(requests);

      expect(results).toHaveLength(10);
      results.forEach(result => {
        expect(result.code).toBe(200);
      });
    });

    it('should handle concurrent requests', async () => {
      const requests = [
        { User: { id: 1 } },
        { User: { id: 2 } },
        { User: { id: 3 } },
      ];

      // Mock database queries
      mockMySQLPool.query.mockResolvedValue([
        [{ id: 1, name: 'Alice' }],
        [],
      ]);

      const results = await Promise.all(requests.map(req => parser.parse(req)));

      expect(results).toHaveLength(3);
      results.forEach(result => {
        expect(result.code).toBe(200);
      });
    });

    it('should handle large result sets', async () => {
      const request = {
        'User[]': {
          count: 1000,
          User: {},
        },
      };

      // Mock large result set
      const largeResult = Array.from({ length: 1000 }, (_, i) => ({
        id: i + 1,
        name: `User${i + 1}`,
        age: 20 + (i % 50),
      }));

      mockMySQLPool.query.mockResolvedValueOnce([largeResult, []]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data.User).toHaveLength(1000);
    });
  });

  describe('Complex Scenarios', () => {
    it('should execute nested query with multiple levels', async () => {
      const request = {
        User: {
          id: 1,
        },
        Moment: {
          userId@': '/User/id',
          Comment: {
            momentId@': '/Moment/id',
          },
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [{ id: 1, name: 'Alice' }],
          [],
        ])
        .mockResolvedValueOnce([
          [{ id: 1, userId: 1, content: 'Test Moment' }],
          [],
        ])
        .mockResolvedValueOnce([
          [{ id: 1, momentId: 1, content: 'Test Comment' }],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Moment');
      expect(result.data.Moment).toHaveProperty('Comment');
    });

    it('should execute query with multiple JOINs', async () => {
      const request = {
        Moment: {
          userId: 82001,
        },
        join: '&/User/id@,&/Comment/toId@',
      };

      // Mock database query
      mockMySQLPool.query.mockResolvedValueOnce([
        [
          { id: 1, userId: 82001, content: 'Test Moment' },
          { id: 82001, name: 'Test User' },
          { id: 1, toId: 1, content: 'Test Comment' },
        ],
        [],
      ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('Moment');
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Comment');
    });

    it('should execute CRUD mixed operations', async () => {
      const request = {
        User: {
          '@method': 'PUT',
          id: 1,
          name: 'Updated Name',
        },
        Moment: {
          '@method': 'POST',
          userId@': '/User/id',
          content: 'New Moment',
        },
        Comment: {
          '@method': 'DELETE',
          id: 1,
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([[{ affectedRows: 1 }], []])
        .mockResolvedValueOnce([[{ insertId: 2 }], []])
        .mockResolvedValueOnce([[{ affectedRows: 1 }], []]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
      expect(result.data).toHaveProperty('Moment');
      expect(result.data).toHaveProperty('Comment');
    });

    it('should execute query with subquery', async () => {
      const request = {
        User: {
          id{}': {
            Moment: {
              userId@': '/User/id',
            },
          },
        },
      };

      // Mock database queries
      mockMySQLPool.query
        .mockResolvedValueOnce([
          [{ id: 1, name: 'Alice' }],
          [],
        ])
        .mockResolvedValueOnce([
          [{ userId: 1 }],
          [],
        ])
        .mockResolvedValueOnce([
          [
            { id: 1, name: 'Alice' },
            { id: 2, name: 'Bob' },
          ],
          [],
        ]);

      const result = await parser.parse(request);

      expect(result.code).toBe(200);
      expect(result.data).toHaveProperty('User');
    });
  });
});
