# APIJSONFinal

APIJSON + JFinal 接近成品的 Demo

### 运行

右键 DemoAppConfig > Run As > Java Application
