# APIJSONDemo

APIJSON + SpringBoot 初级使用的最简单 Demo

### 运行

右键 DemoApplication > Run As > Java Application
