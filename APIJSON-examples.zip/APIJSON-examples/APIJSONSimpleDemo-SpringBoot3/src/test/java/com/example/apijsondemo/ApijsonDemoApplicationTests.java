package com.example.apijsondemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApijsonDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
