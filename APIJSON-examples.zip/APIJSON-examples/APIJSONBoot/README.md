# APIJSONBoot

APIJSON + SpringBoot 接近成品的 Demo

### 运行

右键 DemoApplication > Run As > Java Application

### 自定义 API 的说明（非 APIJSON 万能 API）
https://github.com/xlongwei/light4j/tree/master/apijson#apijson%E8%B4%A6%E6%88%B7%E7%AE%A1%E7%90%86
