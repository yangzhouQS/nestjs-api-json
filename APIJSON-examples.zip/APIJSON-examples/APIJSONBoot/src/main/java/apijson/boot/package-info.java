/**
 * 示例服务端关于 SpingBoot 配置的工程包
 */
/**
 * @author Lemon
 *
 */
package apijson.boot;